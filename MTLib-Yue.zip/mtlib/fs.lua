-- [yue]: mtlib/fs.yue
local fileExists -- 3
fileExists = function(filename) -- 3
	local ioF = io.open(filename, "r+") -- 4
	local result = (ioF ~= nil) -- 5
	if result then -- 6
		ioF:close() -- 6
	end -- 6
	return (result) -- 7
end -- 3
local _anon_func_0 = function(filename, io) -- 11
	local _accum_0 = { } -- 11
	local _len_0 = 1 -- 11
	for line in io.lines(filename) do -- 11
		_accum_0[_len_0] = line -- 11
		_len_0 = _len_0 + 1 -- 11
	end -- 11
	return _accum_0 -- 11
end -- 11
local fileLines -- 9
fileLines = function(filename) -- 9
	if not (fileExists(filename)) then -- 10
		return { } -- 10
	end -- 10
	return (_anon_func_0(filename, io)) -- 11
end -- 9
local FileGenerator -- 13
do -- 13
	local _class_0 -- 13
	local _base_0 = { -- 13
		isValid = function(self) -- 19
			return (self.file_stream ~= nil) -- 19
		end, -- 20
		exists = function(self) -- 20
			assert(self.file_name, "no file name") -- 21
			return (fileExists(self.file_name)) -- 22
		end, -- 23
		write = function(self, data) -- 23
			assert(data, "no data for write") -- 24
			assert(self:isValid(), "invalid file stream") -- 25
			self.file_stream:write(data) -- 26
			return (self) -- 27
		end, -- 28
		read = function(self, what) -- 28
			assert(self:isValid(), "invalid file stream") -- 29
			return (self.file_stream:read((what or "*all"))) -- 30
		end, -- 31
		close = function(self) -- 31
			if self:isValid() then -- 32
				self.file_stream:close() -- 32
			end -- 32
			return (self) -- 33
		end -- 13
	} -- 13
	if _base_0.__index == nil then -- 13
		_base_0.__index = _base_0 -- 13
	end -- 33
	_class_0 = setmetatable({ -- 13
		__init = function(self, file_name, mode) -- 14
			assert(file_name, "no file name") -- 15
			self.file_name = file_name -- 16
			self.file_stream = io.open(file_name, mode or "rw") -- 17
			return (self) -- 18
		end, -- 13
		__base = _base_0, -- 13
		__name = "FileGenerator" -- 13
	}, { -- 13
		__index = _base_0, -- 13
		__call = function(cls, ...) -- 13
			local _self_0 = setmetatable({ }, _base_0) -- 13
			cls.__init(_self_0, ...) -- 13
			return _self_0 -- 13
		end -- 13
	}) -- 13
	_base_0.__class = _class_0 -- 13
	FileGenerator = _class_0 -- 13
end -- 33
return { -- 36
	fileLines = fileLines, -- 36
	fileExists = fileExists, -- 37
	generators = { -- 39
		FileGenerator = FileGenerator -- 39
	} -- 38
} -- 41
