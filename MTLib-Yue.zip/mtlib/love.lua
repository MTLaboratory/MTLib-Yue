-- [yue]: mtlib/love.yue
local love = love or nil -- 1
if (love == nil) then -- 2
	return false -- 2
end -- 2
local graphics, window = love.graphics, love.window -- 4
if not RootPath then -- 6
	error("RootPath not set!") -- 6
end -- 6
local Hexad, Color -- 7
do -- 7
	local _obj_0 = require(tostring(RootPath) .. "maths") -- 7
	Hexad, Color = _obj_0.Hexad, _obj_0.Color -- 7
end -- 7
local isCallable, ensureType, isType, NOOP, deepCopy -- 8
do -- 8
	local _obj_0 = require(tostring(RootPath) .. "logic") -- 8
	isCallable, ensureType, isType, NOOP, deepCopy = _obj_0.isCallable, _obj_0.ensureType, _obj_0.isType, _obj_0.NOOP, _obj_0.deepCopy -- 8
end -- 8
local types -- 9
do -- 9
	local _obj_0 = require(tostring(RootPath) .. "constants") -- 9
	types = _obj_0.types -- 9
end -- 9
local FileGenerator -- 10
do -- 10
	local _obj_0 = require(tostring(RootPath) .. "fs").generators -- 10
	FileGenerator = _obj_0.FileGenerator -- 10
end -- 10
local unpack = unpack or (table.unpack or error("No unpack!")) -- 12
local resolveImageSource -- 14
resolveImageSource = function(source) -- 14
	if (source == nil) then -- 15
		return (nil), (nil) -- 15
	end -- 15
	local srcType = type(source) -- 16
	if srcType == types.STRING then -- 17
		return (graphics.newImage(source)), (source) -- 18
	elseif srcType == types.TABLE then -- 19
		if source.image then -- 20
			return resolveImageSource(source.image) -- 20
		end -- 20
		if source.path then -- 21
			return (graphics.newImage(source.path)), (source.path) -- 22
		end -- 21
		if source.data then -- 23
			return resolveImageSource(source.data) -- 23
		end -- 23
	elseif srcType == types.USERDATA then -- 24
		local success, kind = pcall(function() -- 25
			return source:type() -- 25
		end) -- 25
		if success then -- 26
			if kind == "Image" then -- 27
				return (source), (nil) -- 28
			elseif (kind == "ImageData") or (kind == "CompressedData") or (kind == "FileData") then -- 29
				return (graphics.newImage(source)), (nil) -- 30
			end -- 27
		end -- 26
		return (source), (nil) -- 31
	else -- 33
		local success, kind = pcall(function() -- 33
			return source:type() -- 33
		end) -- 33
		if success then -- 34
			if kind == "Image" then -- 35
				return (source), (nil) -- 36
			elseif (kind == "ImageData") or (kind == "CompressedData") or (kind == "FileData") then -- 37
				return (graphics.newImage(source)), (nil) -- 38
			end -- 35
		end -- 34
	end -- 17
	return error("Unsupported image source for Picture") -- 39
end -- 14
local countEntries -- 41
countEntries = function(tbl) -- 41
	if (tbl == nil) then -- 42
		return 0 -- 42
	end -- 42
	local total = 0 -- 43
	for _ in pairs(tbl) do -- 44
		total = total + 1 -- 44
	end -- 44
	return (total) -- 45
end -- 41
local Projector -- 47
do -- 47
	local _class_0 -- 47
	local _base_0 = { -- 47
		setPosition = function(self, x, y) -- 61
			if x == nil then -- 61
				x = 0 -- 61
			end -- 61
			if y == nil then -- 61
				y = 0 -- 61
			end -- 61
			self.Position:set(tonumber(x or 0), tonumber(y or 0)) -- 62
			return (self) -- 63
		end, -- 64
		move = function(self, dx, dy) -- 64
			if dx == nil then -- 64
				dx = 0 -- 64
			end -- 64
			if dy == nil then -- 64
				dy = 0 -- 64
			end -- 64
			local pX, pY = self.Position:get() -- 65
			self.Position:set(pX + tonumber(dx or 0), pY + tonumber(dy or 0)) -- 66
			return (self) -- 67
		end, -- 68
		setZoom = function(self, zoomX, zoomY) -- 68
			if zoomX == nil then -- 68
				zoomX = 1 -- 68
			end -- 68
			zoomY = zoomY or zoomX -- 69
			self.Scale.x = math.max(1e-4, tonumber(zoomX or 1)) -- 70
			self.Scale.y = math.max(1e-4, tonumber(zoomY or 1)) -- 71
			return (self) -- 72
		end, -- 73
		zoomBy = function(self, factor) -- 73
			if factor == nil then -- 73
				factor = 1 -- 73
			end -- 73
			factor = tonumber(factor or 1) -- 74
			self.Scale.x = math.max(1e-4, self.Scale.x * factor) -- 75
			self.Scale.y = math.max(1e-4, self.Scale.y * factor) -- 76
			return (self) -- 77
		end, -- 78
		setRotation = function(self, rotation) -- 78
			if rotation == nil then -- 78
				rotation = 0 -- 78
			end -- 78
			self.Rotation = tonumber(rotation or 0) -- 79
			return (self) -- 80
		end, -- 81
		rotate = function(self, delta) -- 81
			if delta == nil then -- 81
				delta = 0 -- 81
			end -- 81
			self.Rotation = self.Rotation + tonumber(delta or 0) -- 82
			return (self) -- 83
		end, -- 84
		setViewport = function(self, width, height) -- 84
			if width == nil then -- 84
				width = nil -- 84
			end -- 84
			if height == nil then -- 84
				height = nil -- 84
			end -- 84
			if (width ~= nil) and (height ~= nil) then -- 85
				self.Viewport = { -- 87
					w = tonumber(width), -- 87
					h = tonumber(height) -- 88
				} -- 86
			else -- 91
				self.Viewport = { -- 92
					w = graphics.getWidth(), -- 92
					h = graphics.getHeight() -- 93
				} -- 91
			end -- 85
			return (self) -- 95
		end, -- 96
		getPosition = function(self) -- 96
			return self.Position:get() -- 96
		end, -- 97
		getScale = function(self) -- 97
			return (self.Scale.x), (self.Scale.y) -- 97
		end, -- 98
		getRotation = function(self) -- 98
			return (self.Rotation) -- 98
		end, -- 99
		attach = function(self, originX, originY) -- 99
			if originX == nil then -- 99
				originX = nil -- 99
			end -- 99
			if originY == nil then -- 99
				originY = nil -- 99
			end -- 99
			if self.Active then -- 100
				return (self) -- 100
			end -- 100
			local vW = (self.Viewport and self.Viewport.w or graphics.getWidth()) -- 101
			local vH = (self.Viewport and self.Viewport.h or graphics.getHeight()) -- 102
			originX = originX or (vW * 0.5) -- 103
			originY = originY or (vH * 0.5) -- 104
			graphics.push() -- 105
			graphics.translate(tonumber(originX), tonumber(originY)) -- 106
			graphics.scale(self.Scale.x, self.Scale.y) -- 107
			graphics.rotate(-self.Rotation) -- 108
			local pX, pY = self.Position:get() -- 109
			graphics.translate(-pX, -pY) -- 110
			self.Active = true -- 111
			return (self) -- 112
		end, -- 113
		detach = function(self) -- 113
			if not self.Active then -- 114
				return (self) -- 114
			end -- 114
			graphics.pop() -- 115
			self.Active = false -- 116
			return (self) -- 117
		end, -- 118
		project = function(self, func, originX, originY) -- 118
			if originX == nil then -- 118
				originX = nil -- 118
			end -- 118
			if originY == nil then -- 118
				originY = nil -- 118
			end -- 118
			if not isCallable(func) then -- 119
				return (self) -- 119
			end -- 119
			self:attach(originX, originY) -- 120
			local ok, result = pcall(func, self) -- 121
			self:detach() -- 122
			if not ok then -- 123
				error(result) -- 123
			end -- 123
			return (result) -- 124
		end -- 47
	} -- 47
	if _base_0.__index == nil then -- 47
		_base_0.__index = _base_0 -- 47
	end -- 124
	_class_0 = setmetatable({ -- 47
		__init = function(self, x, y, zoomX, zoomY, rotation) -- 48
			if x == nil then -- 48
				x = 0 -- 48
			end -- 48
			if y == nil then -- 48
				y = 0 -- 48
			end -- 48
			if zoomX == nil then -- 48
				zoomX = 1 -- 48
			end -- 48
			if zoomY == nil then -- 48
				zoomY = zoomX -- 48
			end -- 48
			if rotation == nil then -- 48
				rotation = 0 -- 48
			end -- 48
			self.Position = Hexad(tonumber(x or 0), tonumber(y or 0)) -- 49
			self.Scale = { -- 51
				x = tonumber(zoomX or 1), -- 51
				y = tonumber(zoomY or zoomX or 1) -- 52
			} -- 50
			self.Rotation = tonumber(rotation or 0) -- 54
			self.Viewport = { -- 56
				w = graphics.getWidth(), -- 56
				h = graphics.getHeight() -- 57
			} -- 55
			self.Active = false -- 59
			return (self) -- 60
		end, -- 47
		__base = _base_0, -- 47
		__name = "Projector" -- 47
	}, { -- 47
		__index = _base_0, -- 47
		__call = function(cls, ...) -- 47
			local _self_0 = setmetatable({ }, _base_0) -- 47
			cls.__init(_self_0, ...) -- 47
			return _self_0 -- 47
		end -- 47
	}) -- 47
	_base_0.__class = _class_0 -- 47
	Projector = _class_0 -- 47
end -- 124
local View -- 126
do -- 126
	local _class_0 -- 126
	local _base_0 = { -- 126
		configure = function(self, param, value) -- 160
			if value == nil then -- 160
				value = nil -- 160
			end -- 160
			if (type(param) == types.TABLE) then -- 161
				for k, v in pairs(param) do -- 162
					self.Conf[k] = v -- 162
				end -- 162
			else -- 164
				self.Conf[param] = value -- 164
			end -- 161
			self:markDirty() -- 165
			return (self) -- 166
		end, -- 167
		renderTo = function(self, func) -- 167
			self.Canvas:renderTo(func) -- 168
			return (self) -- 169
		end, -- 170
		markDirty = function(self) -- 170
			self.Dirty = true -- 171
			return (self) -- 172
		end, -- 173
		isDirty = function(self) -- 173
			return (self.Dirty == true) -- 173
		end, -- 174
		getPosition = function(self) -- 174
			return self.Position:get() -- 174
		end, -- 175
		getDimensions = function(self) -- 175
			return (self.Size.w), (self.Size.h) -- 175
		end, -- 176
		setPosition = function(self, x, y) -- 176
			if x == nil then -- 176
				x = nil -- 176
			end -- 176
			if y == nil then -- 176
				y = nil -- 176
			end -- 176
			local posX = tonumber((x ~= nil) and x or self.Position.Position.x) -- 177
			local posY = tonumber((y ~= nil) and y or self.Position.Position.y) -- 178
			self.Position:set(posX, posY) -- 179
			if self.Projector then -- 180
				self.Projector:setPosition(posX, posY) -- 180
			end -- 180
			self:markDirty() -- 181
			return (self) -- 182
		end, -- 183
		moveBy = function(self, dx, dy) -- 183
			if dx == nil then -- 183
				dx = 0 -- 183
			end -- 183
			if dy == nil then -- 183
				dy = 0 -- 183
			end -- 183
			local posX = self.Position.Position.x + tonumber(dx or 0) -- 184
			local posY = self.Position.Position.y + tonumber(dy or 0) -- 185
			self:setPosition(posX, posY) -- 186
			return (self) -- 187
		end, -- 188
		setDimensions = function(self, width, height) -- 188
			width = tonumber(width or self.Size.w) -- 189
			height = tonumber(height or self.Size.h) -- 190
			if (width ~= self.Size.w) or (height ~= self.Size.h) then -- 191
				self.Size.w, self.Size.h = width, height -- 192
				self.Canvas = graphics.newCanvas(width, height) -- 193
				self.Projector:setViewport(width, height) -- 194
				self:markDirty() -- 195
			end -- 191
			return (self) -- 196
		end, -- 197
		getProjector = function(self) -- 197
			return (self.Projector) -- 197
		end, -- 198
		addChild = function(self, element, index) -- 198
			if index == nil then -- 198
				index = nil -- 198
			end -- 198
			if (element == nil) then -- 199
				return (self) -- 199
			end -- 199
			index = index or (#self.Children + 1) -- 200
			table.insert(self.Children, index, element) -- 201
			self:markDirty() -- 202
			return (self) -- 203
		end, -- 204
		removeChild = function(self, element) -- 204
			if (element == nil) then -- 205
				return (false) -- 205
			end -- 205
			for idx, child in ipairs(self.Children) do -- 206
				if (child == element) then -- 207
					table.remove(self.Children, idx) -- 208
					self:markDirty() -- 209
					return (true) -- 210
				end -- 207
			end -- 210
			return (false) -- 211
		end, -- 212
		clearChildren = function(self) -- 212
			if (#self.Children == 0) then -- 213
				return (self) -- 213
			end -- 213
			self.Children = { } -- 214
			self:markDirty() -- 215
			return (self) -- 216
		end, -- 217
		eachChild = function(self, func) -- 217
			if not isCallable(func) then -- 218
				return (self) -- 218
			end -- 218
			for idx, child in ipairs(self.Children) do -- 219
				func(child, idx) -- 219
			end -- 219
			return (self) -- 220
		end, -- 221
		drawChildren = function(self) -- 221
			for _, child in ipairs(self.Children) do -- 222
				if (child ~= nil) and (child.isVisible == nil or child:isVisible()) then -- 223
					child:draw() -- 224
				end -- 223
			end -- 224
			return (self) -- 225
		end, -- 226
		render = function(self) -- 226
			local clearColor = (self.Conf.clearColor or { -- 227
				0, -- 227
				0, -- 227
				0, -- 227
				0 -- 227
			}) -- 227
			self.Canvas:renderTo(function() -- 228
				graphics.clear(unpack(clearColor)) -- 229
				graphics.setColor(1, 1, 1, 1) -- 230
				return self:drawChildren() -- 231
			end) -- 228
			self.Dirty = false -- 233
			return (self) -- 234
		end, -- 235
		draw = function(self, x, y, r, sX, sY) -- 235
			if x == nil then -- 235
				x = nil -- 235
			end -- 235
			if y == nil then -- 235
				y = nil -- 235
			end -- 235
			if r == nil then -- 235
				r = 0 -- 235
			end -- 235
			if sX == nil then -- 235
				sX = 1 -- 235
			end -- 235
			if sY == nil then -- 235
				sY = 1 -- 235
			end -- 235
			if self.Dirty then -- 236
				self:render() -- 236
			end -- 236
			local drawX = tonumber(x or self.Position.Position.x) -- 237
			local drawY = tonumber(y or self.Position.Position.y) -- 238
			graphics.setColor(1, 1, 1, 1) -- 239
			graphics.draw(self.Canvas, drawX, drawY, tonumber(r or 0), tonumber(sX or 1), tonumber(sY or 1)) -- 240
			return (self) -- 241
		end -- 126
	} -- 126
	if _base_0.__index == nil then -- 126
		_base_0.__index = _base_0 -- 126
	end -- 241
	_class_0 = setmetatable({ -- 126
		__init = function(self, oX, oY, w, h, options) -- 127
			if oX == nil then -- 127
				oX = 0 -- 127
			end -- 127
			if oY == nil then -- 127
				oY = 0 -- 127
			end -- 127
			if w == nil then -- 127
				w = nil -- 127
			end -- 127
			if h == nil then -- 127
				h = nil -- 127
			end -- 127
			if options == nil then -- 127
				options = nil -- 127
			end -- 127
			if (oX ~= nil) and (type(oX) == types.TABLE) then -- 128
				options = oX -- 129
				oX = tonumber(options.x or options[1] or 0) -- 130
				oY = tonumber(options.y or options[2] or 0) -- 131
				w = (options.width or options.w or options[3]) -- 132
				h = (options.height or options.h or options[4]) -- 133
			elseif (w ~= nil) and (type(w) == types.TABLE) and (options == nil) then -- 134
				options = w -- 135
				w = options.width or options.w -- 136
				h = options.height or options.h -- 137
			elseif (h ~= nil) and (type(h) == types.TABLE) and (options == nil) then -- 138
				options = h -- 139
				h = options.height or options.h -- 140
			end -- 128
			local width = tonumber(w or graphics.getWidth()) -- 141
			local height = tonumber(h or graphics.getHeight()) -- 142
			self.Position = Hexad(tonumber(oX or 0), tonumber(oY or 0)) -- 143
			self.Size = { -- 145
				w = width, -- 145
				h = height -- 146
			} -- 144
			self.Conf = { -- 149
				margin = 0, -- 149
				clearColor = { -- 150
					0, -- 150
					0, -- 150
					0, -- 150
					0 -- 150
				} -- 150
			} -- 148
			if (options ~= nil) and (type(options) == types.TABLE) then -- 152
				for k, v in pairs(options) do -- 153
					self.Conf[k] = v -- 153
				end -- 153
			end -- 152
			self.Canvas = graphics.newCanvas(width, height) -- 154
			self.Children = { } -- 155
			self.Dirty = true -- 156
			self.Projector = Projector(self.Position.Position.x, self.Position.Position.y) -- 157
			self.Projector:setViewport(width, height) -- 158
			return (self) -- 159
		end, -- 126
		__base = _base_0, -- 126
		__name = "View" -- 126
	}, { -- 126
		__index = _base_0, -- 126
		__call = function(cls, ...) -- 126
			local _self_0 = setmetatable({ }, _base_0) -- 126
			cls.__init(_self_0, ...) -- 126
			return _self_0 -- 126
		end -- 126
	}) -- 126
	_base_0.__class = _class_0 -- 126
	View = _class_0 -- 126
end -- 241
local ListView -- 243
do -- 243
	local _class_0 -- 243
	local _parent_0 = View -- 243
	local _base_0 = { -- 243
		setSpacing = function(self, value) -- 258
			self.Spacing = tonumber(value or self.Spacing or 4) -- 259
			self:layout() -- 260
			return (self) -- 261
		end, -- 262
		setAlignment = function(self, alignment) -- 262
			self.Conf.alignment = (alignment or self.Conf.alignment or "left") -- 263
			self:layout() -- 264
			return (self) -- 265
		end, -- 266
		setDirection = function(self, direction) -- 266
			direction = string.lower(tostring(direction or "vertical")) -- 267
			if (direction ~= self.Conf.direction) then -- 268
				self.Conf.direction = direction -- 269
				self:layout() -- 270
			end -- 268
			return (self) -- 271
		end, -- 272
		addChild = function(self, element, index) -- 272
			if index == nil then -- 272
				index = nil -- 272
			end -- 272
			_class_0.__parent.addChild(self, element, index) -- 273
			self:layout() -- 274
			return (self) -- 275
		end, -- 276
		removeChild = function(self, element) -- 276
			local removed = _class_0.__parent.removeChild(self, element) -- 277
			if removed then -- 278
				self:layout() -- 278
			end -- 278
			return (removed) -- 279
		end, -- 280
		layout = function(self) -- 280
			if (#self.Children == 0) then -- 281
				self.ContentSize = { -- 282
					w = 0, -- 282
					h = 0 -- 282
				} -- 282
				return (self) -- 283
			end -- 281
			local margin = tonumber(self.Conf.margin or 0) -- 284
			local width, height = self:getDimensions() -- 285
			local cursorX, cursorY = margin, margin -- 286
			local maxLine = 0 -- 287
			for _, child in ipairs(self.Children) do -- 288
				if (child ~= nil) and (child.isVisible == nil or child:isVisible()) then -- 289
					local cW, cH = child:getSize() -- 290
					cW = tonumber(cW or (width - margin * 2)) -- 291
					cH = tonumber(cH or graphics.getFont():getHeight()) -- 292
					local availableW = math.max(0, width - (margin * 2)) -- 293
					if cW > availableW then -- 294
						cW = availableW -- 294
					end -- 294
					if (self.Conf.direction == "horizontal") then -- 295
						child:setPosition(cursorX, margin) -- 296
						child:setSize(cW, cH) -- 297
						cursorX = cursorX + (cW + self.Spacing) -- 298
						maxLine = math.max(maxLine, cH) -- 299
					else -- 301
						local offsetX = margin -- 301
						local align = string.lower(tostring(self.Conf.alignment or "left")) -- 302
						if align == "center" then -- 303
							offsetX = margin + math.floor((availableW - cW) * 0.5) -- 304
						elseif align == "right" then -- 305
							offsetX = margin + (availableW - cW) -- 306
						end -- 303
						child:setPosition(offsetX, cursorY) -- 307
						child:setSize(cW, cH) -- 308
						cursorY = cursorY + (cH + self.Spacing) -- 309
						maxLine = cursorY -- 310
					end -- 295
				end -- 289
			end -- 310
			if (self.Conf.direction == "horizontal") then -- 311
				self.ContentSize = { -- 313
					w = cursorX - self.Spacing + margin, -- 313
					h = math.max(maxLine, height) -- 314
				} -- 312
			else -- 317
				self.ContentSize = { -- 318
					w = width, -- 318
					h = math.max(maxLine - self.Spacing, margin) -- 319
				} -- 317
			end -- 311
			self:markDirty() -- 321
			return (self) -- 322
		end, -- 323
		drawChildren = function(self) -- 323
			if self.Dirty then -- 324
				self:layout() -- 324
			end -- 324
			return _class_0.__parent.drawChildren(self) -- 325
		end -- 243
	} -- 243
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 325
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 243
			_base_0[_key_0] = _val_0 -- 243
		end -- 243
	end -- 325
	if _base_0.__index == nil then -- 243
		_base_0.__index = _base_0 -- 243
	end -- 325
	setmetatable(_base_0, _parent_0.__base) -- 243
	_class_0 = setmetatable({ -- 243
		__init = function(self, oX, oY, w, h, options) -- 244
			if oX == nil then -- 244
				oX = 0 -- 244
			end -- 244
			if oY == nil then -- 244
				oY = 0 -- 244
			end -- 244
			if w == nil then -- 244
				w = nil -- 244
			end -- 244
			if h == nil then -- 244
				h = nil -- 244
			end -- 244
			if options == nil then -- 244
				options = nil -- 244
			end -- 244
			local useOptions = options -- 245
			if (oX ~= nil) and (type(oX) == types.TABLE) then -- 246
				useOptions = oX -- 247
				oX = useOptions.x or useOptions[1] or 0 -- 248
				oY = useOptions.y or useOptions[2] or 0 -- 249
				w = useOptions.width or useOptions.w or useOptions[3] -- 250
				h = useOptions.height or useOptions.h or useOptions[4] -- 251
			end -- 246
			_class_0.__parent.__init(self, oX, oY, w, h, useOptions) -- 252
			local opts = (useOptions or { }) -- 253
			self.Spacing = tonumber(opts.spacing or opts.gap or 4) -- 254
			local _obj_0 = self.Conf -- 255
			_obj_0.alignment = _obj_0.alignment or (opts.alignment or opts.align or "left") -- 255
			local _obj_1 = self.Conf -- 256
			_obj_1.direction = _obj_1.direction or (opts.direction or "vertical") -- 256
			return (self) -- 257
		end, -- 243
		__base = _base_0, -- 243
		__name = "ListView", -- 243
		__parent = _parent_0 -- 243
	}, { -- 243
		__index = function(cls, name) -- 243
			local val = rawget(_base_0, name) -- 243
			if val == nil then -- 243
				local parent = rawget(cls, "__parent") -- 243
				if parent then -- 243
					return parent[name] -- 243
				end -- 243
			else -- 243
				return val -- 243
			end -- 243
		end, -- 243
		__call = function(cls, ...) -- 243
			local _self_0 = setmetatable({ }, _base_0) -- 243
			cls.__init(_self_0, ...) -- 243
			return _self_0 -- 243
		end -- 243
	}) -- 243
	_base_0.__class = _class_0 -- 243
	if _parent_0.__inherited then -- 243
		_parent_0.__inherited(_parent_0, _class_0) -- 243
	end -- 243
	ListView = _class_0 -- 243
end -- 325
local GridView -- 327
do -- 327
	local _class_0 -- 327
	local _parent_0 = ListView -- 327
	local _base_0 = { -- 327
		setColumns = function(self, count) -- 340
			self.Columns = math.max(1, tonumber(count or self.Columns or 1)) -- 341
			self:layout() -- 342
			return (self) -- 343
		end, -- 344
		layout = function(self) -- 344
			if (#self.Children == 0) then -- 345
				self.ContentSize = { -- 346
					w = 0, -- 346
					h = 0 -- 346
				} -- 346
				return (self) -- 347
			end -- 345
			local margin = tonumber(self.Conf.margin or 0) -- 348
			local spacing = tonumber(self.Spacing or 0) -- 349
			local width, _ = self:getDimensions() -- 350
			local availableWidth = math.max(0, width - (margin * 2)) -- 351
			local cellWidth = 0 -- 352
			if (self.Columns > 0) then -- 353
				cellWidth = (availableWidth - (spacing * (self.Columns - 1))) / self.Columns -- 354
			end -- 353
			local cursorX, cursorY = margin, margin -- 355
			local colIndex = 1 -- 356
			local rowHeight = 0 -- 357
			local totalHeight = margin -- 358
			for _, child in ipairs(self.Children) do -- 359
				if (child ~= nil) and (child.isVisible == nil or child:isVisible()) then -- 360
					local cW, cH = child:getSize() -- 361
					cW = tonumber(cW or cellWidth) -- 362
					cH = tonumber(cH or graphics.getFont():getHeight()) -- 363
					if cW > cellWidth then -- 364
						cW = cellWidth -- 364
					end -- 364
					child:setPosition(cursorX, cursorY) -- 365
					child:setSize(math.max(0, cW), math.max(0, cH)) -- 366
					rowHeight = math.max(rowHeight, cH) -- 367
					if colIndex >= self.Columns then -- 368
						colIndex = 1 -- 369
						cursorX = margin -- 370
						cursorY = cursorY + (rowHeight + spacing) -- 371
						totalHeight = cursorY -- 372
						rowHeight = 0 -- 373
					else -- 375
						colIndex = colIndex + 1 -- 375
						cursorX = cursorX + (cellWidth + spacing) -- 376
					end -- 368
				end -- 360
			end -- 376
			if rowHeight > 0 then -- 377
				totalHeight = totalHeight + rowHeight -- 377
			end -- 377
			self.ContentSize = { -- 379
				w = width, -- 379
				h = totalHeight -- 380
			} -- 378
			self:markDirty() -- 382
			return (self) -- 383
		end -- 327
	} -- 327
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 383
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 327
			_base_0[_key_0] = _val_0 -- 327
		end -- 327
	end -- 383
	if _base_0.__index == nil then -- 327
		_base_0.__index = _base_0 -- 327
	end -- 383
	setmetatable(_base_0, _parent_0.__base) -- 327
	_class_0 = setmetatable({ -- 327
		__init = function(self, oX, oY, w, h, options) -- 328
			if oX == nil then -- 328
				oX = 0 -- 328
			end -- 328
			if oY == nil then -- 328
				oY = 0 -- 328
			end -- 328
			if w == nil then -- 328
				w = nil -- 328
			end -- 328
			if h == nil then -- 328
				h = nil -- 328
			end -- 328
			if options == nil then -- 328
				options = nil -- 328
			end -- 328
			local useOptions = options -- 329
			if (oX ~= nil) and (type(oX) == types.TABLE) then -- 330
				useOptions = oX -- 331
				oX = useOptions.x or useOptions[1] or 0 -- 332
				oY = useOptions.y or useOptions[2] or 0 -- 333
				w = useOptions.width or useOptions.w or useOptions[3] -- 334
				h = useOptions.height or useOptions.h or useOptions[4] -- 335
			end -- 330
			_class_0.__parent.__init(self, oX, oY, w, h, useOptions) -- 336
			local opts = (useOptions or { }) -- 337
			self.Columns = math.max(1, tonumber(opts.columns or opts.cols or 2)) -- 338
			return (self) -- 339
		end, -- 327
		__base = _base_0, -- 327
		__name = "GridView", -- 327
		__parent = _parent_0 -- 327
	}, { -- 327
		__index = function(cls, name) -- 327
			local val = rawget(_base_0, name) -- 327
			if val == nil then -- 327
				local parent = rawget(cls, "__parent") -- 327
				if parent then -- 327
					return parent[name] -- 327
				end -- 327
			else -- 327
				return val -- 327
			end -- 327
		end, -- 327
		__call = function(cls, ...) -- 327
			local _self_0 = setmetatable({ }, _base_0) -- 327
			cls.__init(_self_0, ...) -- 327
			return _self_0 -- 327
		end -- 327
	}) -- 327
	_base_0.__class = _class_0 -- 327
	if _parent_0.__inherited then -- 327
		_parent_0.__inherited(_parent_0, _class_0) -- 327
	end -- 327
	GridView = _class_0 -- 327
end -- 383
local Element -- 385
do -- 385
	local _class_0 -- 385
	local _base_0 = { -- 385
		setPosition = function(self, x, y) -- 409
			if x == nil then -- 409
				x = 0 -- 409
			end -- 409
			if y == nil then -- 409
				y = 0 -- 409
			end -- 409
			self.Position:set(tonumber(x or 0), tonumber(y or 0)) -- 410
			return (self) -- 411
		end, -- 412
		moveBy = function(self, dx, dy) -- 412
			if dx == nil then -- 412
				dx = 0 -- 412
			end -- 412
			if dy == nil then -- 412
				dy = 0 -- 412
			end -- 412
			local pX, pY = self.Position:get() -- 413
			self.Position:set(pX + tonumber(dx or 0), pY + tonumber(dy or 0)) -- 414
			return (self) -- 415
		end, -- 416
		getPosition = function(self) -- 416
			return (self.Position.Position.x), (self.Position.Position.y) -- 416
		end, -- 417
		setSize = function(self, w, h) -- 417
			if w == nil then -- 417
				w = 0 -- 417
			end -- 417
			if h == nil then -- 417
				h = 0 -- 417
			end -- 417
			self.Size.w = tonumber(w or 0) -- 418
			self.Size.h = tonumber(h or 0) -- 419
			return (self) -- 420
		end, -- 421
		getSize = function(self) -- 421
			return (self.Size.w or 0), (self.Size.h or 0) -- 421
		end, -- 422
		getBounds = function(self) -- 422
			local pX, pY = self:getPosition() -- 423
			local sW, sH = self:getSize() -- 424
			return (pX), (pY), (sW), (sH) -- 425
		end, -- 426
		hitTest = function(self, x, y) -- 426
			if (x == nil) or (y == nil) then -- 427
				return (false) -- 427
			end -- 427
			local pX, pY, sW, sH = self:getBounds() -- 428
			return ((x >= pX) and (x <= (pX + sW)) and (y >= pY) and (y <= (pY + sH))) -- 429
		end, -- 430
		setVisible = function(self, visible) -- 430
			if visible == nil then -- 430
				visible = true -- 430
			end -- 430
			self.Visible = (visible ~= false) -- 431
			return (self) -- 432
		end, -- 433
		isVisible = function(self) -- 433
			return (self.Visible ~= false) -- 433
		end, -- 434
		setFont = function(self, font) -- 434
			self.Font = font -- 435
			return (self) -- 436
		end, -- 437
		getFont = function(self) -- 437
			return (self.Font or graphics.getFont()) -- 437
		end, -- 438
		configure = function(self, param, value) -- 438
			if value == nil then -- 438
				value = nil -- 438
			end -- 438
			if (type(param) == types.TABLE) then -- 439
				for k, v in pairs(param) do -- 440
					self.Conf[k] = v -- 440
				end -- 440
			else -- 442
				self.Conf[param] = value -- 442
			end -- 439
			return (self) -- 443
		end, -- 444
		getConf = function(self, param, fallback) -- 444
			if fallback == nil then -- 444
				fallback = nil -- 444
			end -- 444
			return (self.Conf[param] or fallback) -- 444
		end, -- 445
		draw = function(self) -- 445
			return (self) -- 446
		end -- 385
	} -- 385
	if _base_0.__index == nil then -- 385
		_base_0.__index = _base_0 -- 385
	end -- 446
	_class_0 = setmetatable({ -- 385
		__init = function(self, x, y, w, h, options) -- 386
			if x == nil then -- 386
				x = 0 -- 386
			end -- 386
			if y == nil then -- 386
				y = 0 -- 386
			end -- 386
			if w == nil then -- 386
				w = 0 -- 386
			end -- 386
			if h == nil then -- 386
				h = 0 -- 386
			end -- 386
			if options == nil then -- 386
				options = nil -- 386
			end -- 386
			local opts = options -- 387
			if (type(x) == types.TABLE) then -- 388
				opts = x -- 389
				x = opts.x or opts[1] or 0 -- 390
				y = opts.y or opts[2] or 0 -- 391
				w = opts.width or opts.w or opts[3] or w -- 392
				h = opts.height or opts.h or opts[4] or h -- 393
			elseif (type(w) == types.TABLE) and (opts == nil) then -- 394
				opts = w -- 395
				w = opts.width or opts.w or w -- 396
				h = opts.height or opts.h or h -- 397
			end -- 388
			self.Position = Hexad(tonumber(x or 0), tonumber(y or 0)) -- 398
			self.Size = { -- 400
				w = tonumber(w or 0), -- 400
				h = tonumber(h or 0) -- 401
			} -- 399
			self.Conf = { } -- 403
			if (opts ~= nil) and (type(opts) == types.TABLE) then -- 404
				for k, v in pairs(opts) do -- 405
					self.Conf[k] = v -- 405
				end -- 405
			end -- 404
			self.Visible = true -- 406
			self.Font = nil -- 407
			return (self) -- 408
		end, -- 385
		__base = _base_0, -- 385
		__name = "Element" -- 385
	}, { -- 385
		__index = _base_0, -- 385
		__call = function(cls, ...) -- 385
			local _self_0 = setmetatable({ }, _base_0) -- 385
			cls.__init(_self_0, ...) -- 385
			return _self_0 -- 385
		end -- 385
	}) -- 385
	_base_0.__class = _class_0 -- 385
	Element = _class_0 -- 385
end -- 446
local Label -- 448
do -- 448
	local _class_0 -- 448
	local _parent_0 = Element -- 448
	local _base_0 = { -- 448
		draw = function(self) -- 469
			if (graphics.isActive() == false) then -- 470
				return (nil) -- 470
			end -- 470
			if not self:isVisible() then -- 471
				return (self) -- 471
			end -- 471
			local pX, pY = self:getPosition() -- 472
			local width, _ = self:getSize() -- 473
			local font = self:getFont() -- 474
			local effectiveWidth = (width > 0) and width or font:getWidth(self.Text) -- 475
			local limit = (effectiveWidth > 0) and effectiveWidth or window.toPixels(#self.Text) -- 476
			local activeFont = graphics.getFont() -- 477
			local useFont = self:getFont() -- 478
			if useFont ~= activeFont then -- 479
				graphics.setFont(useFont) -- 479
			end -- 479
			if (self.Shadow ~= nil) then -- 480
				local sX = pX + (self.Shadow.x or 1) -- 481
				local sY = pY + (self.Shadow.y or 1) -- 482
				local shadowColor = (self.Shadow.color or { -- 483
					0, -- 483
					0, -- 483
					0, -- 483
					0.6 -- 483
				}) -- 483
				graphics.setColor(unpack(shadowColor)) -- 484
				graphics.printf(self.Text, sX, sY, limit, self.Align) -- 485
			end -- 480
			graphics.setColor(unpack(self.Color or { -- 486
				1, -- 486
				1, -- 486
				1, -- 486
				1 -- 486
			})) -- 486
			graphics.printf(self.Text, pX, pY, limit, self.Align) -- 487
			graphics.setColor(1, 1, 1, 1) -- 488
			if useFont ~= activeFont then -- 489
				graphics.setFont(activeFont) -- 489
			end -- 489
			return (self) -- 490
		end, -- 491
		setText = function(self, value) -- 491
			self.Text = tostring(value or "") -- 492
			local font = self:getFont() -- 493
			local width, height = self:getSize() -- 494
			if width == 0 then -- 495
				self.Size.w = font:getWidth(self.Text) -- 495
			end -- 495
			if height == 0 then -- 496
				self.Size.h = font:getHeight() -- 496
			end -- 496
			return (self) -- 497
		end, -- 498
		setColor = function(self, color) -- 498
			ensureType(color, types.TABLE) -- 499
			self.Color = color -- 500
			return (self) -- 501
		end -- 448
	} -- 448
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 501
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 448
			_base_0[_key_0] = _val_0 -- 448
		end -- 448
	end -- 501
	if _base_0.__index == nil then -- 448
		_base_0.__index = _base_0 -- 448
	end -- 501
	setmetatable(_base_0, _parent_0.__base) -- 448
	_class_0 = setmetatable({ -- 448
		__init = function(self, text, alignment) -- 449
			if alignment == nil then -- 449
				alignment = 'center' -- 449
			end -- 449
			local opts = nil -- 450
			if (type(alignment) == types.TABLE) then -- 451
				opts = alignment -- 452
				alignment = opts.alignment or opts.align or 'center' -- 453
			else -- 455
				opts = { } -- 455
			end -- 451
			_class_0.__parent.__init(self, opts) -- 456
			self.Text = (tostring(text) or [[NIL]]) -- 457
			self.Align = alignment -- 458
			self.Color = opts.color or { -- 459
				1, -- 459
				1, -- 459
				1, -- 459
				1 -- 459
			} -- 459
			self.Shadow = opts.shadow or nil -- 460
			if (opts.font ~= nil) then -- 461
				self:setFont(opts.font) -- 461
			end -- 461
			local font = self:getFont() -- 462
			local width = tonumber(opts.width or opts.w or self.Conf.width or 0) -- 463
			local height = tonumber(opts.height or opts.h or self.Conf.height or 0) -- 464
			if (width == 0) then -- 465
				width = font:getWidth(self.Text) -- 465
			end -- 465
			if (height == 0) then -- 466
				height = font:getHeight() -- 466
			end -- 466
			self:setSize(width, height) -- 467
			return (self) -- 468
		end, -- 448
		__base = _base_0, -- 448
		__name = "Label", -- 448
		__parent = _parent_0 -- 448
	}, { -- 448
		__index = function(cls, name) -- 448
			local val = rawget(_base_0, name) -- 448
			if val == nil then -- 448
				local parent = rawget(cls, "__parent") -- 448
				if parent then -- 448
					return parent[name] -- 448
				end -- 448
			else -- 448
				return val -- 448
			end -- 448
		end, -- 448
		__call = function(cls, ...) -- 448
			local _self_0 = setmetatable({ }, _base_0) -- 448
			cls.__init(_self_0, ...) -- 448
			return _self_0 -- 448
		end -- 448
	}) -- 448
	_base_0.__class = _class_0 -- 448
	if _parent_0.__inherited then -- 448
		_parent_0.__inherited(_parent_0, _class_0) -- 448
	end -- 448
	Label = _class_0 -- 448
end -- 501
local Button -- 503
do -- 503
	local _class_0 -- 503
	local _parent_0 = Element -- 503
	local _base_0 = { -- 503
		isEnabled = function(self) -- 542
			return (self.State.enabled ~= false) -- 542
		end, -- 543
		setEnabled = function(self, enabled) -- 543
			if enabled == nil then -- 543
				enabled = true -- 543
			end -- 543
			self.State.enabled = (enabled ~= false) -- 544
			if not self.State.enabled then -- 545
				self.State.active = false -- 545
			end -- 545
			return (self) -- 546
		end, -- 547
		setCallback = function(self, fn) -- 547
			if (fn ~= nil) and (not isCallable(fn)) then -- 548
				error("Button callback must be callable") -- 548
			end -- 548
			self.OnPressed = (fn or NOOP) -- 549
			return (self) -- 550
		end, -- 551
		setText = function(self, value) -- 551
			self.Text = tostring(value or "") -- 552
			local font = self:getFont() -- 553
			local width, height = self:getSize() -- 554
			local minW = font:getWidth(self.Text) + (self.Padding * 2) -- 555
			if width < minW then -- 556
				self.Size.w = minW -- 556
			end -- 556
			return (self) -- 557
		end, -- 558
		update = function(self, dT) -- 558
			if not self:isEnabled() then -- 559
				return (false) -- 559
			end -- 559
			local hovered = self:hitTest(love.mouse.getX(), love.mouse.getY()) and self:isVisible() -- 560
			self.State.hover = hovered -- 561
			local isDown = love.mouse.isDown(1) -- 562
			local wasDown = wasDown or self.State.pressedLastFrame -- 563
			local triggered = false -- 564
			if hovered and isDown and not wasDown then -- 565
				self.State.active = true -- 566
			elseif not isDown and self.State.active then -- 567
				if hovered then -- 568
					triggered = true -- 569
					self:OnPressed(self) -- 570
				end -- 568
				self.State.active = false -- 571
			elseif not hovered then -- 572
				self.State.active = false -- 573
			end -- 565
			self.State.pressedLastFrame = (isDown == true) -- 574
			return (triggered) -- 575
		end, -- 576
		draw = function(self) -- 576
			if (graphics.isActive() == false) then -- 577
				return (nil) -- 577
			end -- 577
			if not self:isVisible() then -- 578
				return (self) -- 578
			end -- 578
			local pX, pY, width, height = self:getBounds() -- 579
			local state = (self.State.active and "active") or (self.State.hover and "hover") or "normal" -- 580
			local fillColor = self.Colors[state] or self.Colors.normal -- 581
			graphics.setColor(unpack(fillColor())) -- 582
			graphics.rectangle("fill", pX, pY, width, height, self.Radius, self.Radius) -- 583
			if self.Colors.border then -- 584
				graphics.setColor(unpack(self.Colors.border())) -- 585
				graphics.rectangle("line", pX, pY, width, height, self.Radius, self.Radius) -- 586
			end -- 584
			local activeFont = graphics.getFont() -- 587
			local useFont = self:getFont() -- 588
			if useFont ~= activeFont then -- 589
				graphics.setFont(useFont) -- 589
			end -- 589
			graphics.setColor(unpack(self.Colors.text() or Color(1, 1, 1, 1)())) -- 590
			local fontHeight = useFont:getHeight() -- 591
			local textY = pY + math.max(self.Padding, (height - fontHeight) * 0.5) -- 592
			graphics.printf(self.Text, pX + self.Padding, textY, math.max(1, width - (self.Padding * 2)), 'center') -- 593
			graphics.setColor(1, 1, 1, 1) -- 594
			if useFont ~= activeFont then -- 595
				graphics.setFont(activeFont) -- 595
			end -- 595
			return (self) -- 596
		end -- 503
	} -- 503
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 596
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 503
			_base_0[_key_0] = _val_0 -- 503
		end -- 503
	end -- 596
	if _base_0.__index == nil then -- 503
		_base_0.__index = _base_0 -- 503
	end -- 596
	setmetatable(_base_0, _parent_0.__base) -- 503
	_class_0 = setmetatable({ -- 503
		__init = function(self, label, options) -- 504
			if label == nil then -- 504
				label = 'Button' -- 504
			end -- 504
			if options == nil then -- 504
				options = nil -- 504
			end -- 504
			local opts = options -- 505
			if (type(label) == types.TABLE) and (opts == nil) then -- 506
				opts = label -- 507
				label = opts.text or opts.label or 'Button' -- 508
			end -- 506
			opts = opts or { } -- 509
			_class_0.__parent.__init(self, opts) -- 510
			self.Text = tostring(label or "") -- 511
			self.Padding = tonumber(opts.padding or 8) -- 512
			self.Radius = tonumber(opts.radius or 4) -- 513
			self.Colors = { -- 515
				normal = opts.color or Color(0.2, 0.2, 0.26, 1), -- 515
				hover = opts.hoverColor or Color(0.26, 0.26, 0.32, 1), -- 516
				active = opts.activeColor or Color(0.16, 0.16, 0.22, 1), -- 517
				text = opts.textColor or Color(1, 1, 1, 1), -- 518
				border = opts.borderColor or Color(0, 0, 0, 0.45) -- 519
			} -- 514
			if opts.font then -- 521
				self:setFont(opts.font) -- 522
			end -- 521
			local font = self:getFont() -- 523
			local textW = font:getWidth(self.Text) -- 524
			local textH = font:getHeight() -- 525
			local width = tonumber(opts.width or opts.w or (textW + (self.Padding * 2))) -- 526
			local height = tonumber(opts.height or opts.h or (textH + (self.Padding * 2))) -- 527
			self:setSize(width, height) -- 528
			local cb = (opts.onPressed or opts.onClick or opts.callback) -- 529
			if cb ~= nil then -- 530
				if not isCallable(cb) then -- 531
					error("Button callback must be callable") -- 531
				end -- 531
				self.OnPressed = cb -- 532
			else -- 534
				self.OnPressed = NOOP -- 534
			end -- 530
			self.State = { -- 536
				hover = false, -- 536
				active = false, -- 537
				enabled = (opts.enabled ~= false), -- 538
				pressedLastFrame = false -- 539
			} -- 535
			return (self) -- 541
		end, -- 503
		__base = _base_0, -- 503
		__name = "Button", -- 503
		__parent = _parent_0 -- 503
	}, { -- 503
		__index = function(cls, name) -- 503
			local val = rawget(_base_0, name) -- 503
			if val == nil then -- 503
				local parent = rawget(cls, "__parent") -- 503
				if parent then -- 503
					return parent[name] -- 503
				end -- 503
			else -- 503
				return val -- 503
			end -- 503
		end, -- 503
		__call = function(cls, ...) -- 503
			local _self_0 = setmetatable({ }, _base_0) -- 503
			cls.__init(_self_0, ...) -- 503
			return _self_0 -- 503
		end -- 503
	}) -- 503
	_base_0.__class = _class_0 -- 503
	if _parent_0.__inherited then -- 503
		_parent_0.__inherited(_parent_0, _class_0) -- 503
	end -- 503
	Button = _class_0 -- 503
end -- 596
local Textbox -- 598
do -- 598
	local _class_0 -- 598
	local _parent_0 = Element -- 598
	local _base_0 = { -- 598
		focus = function(self) -- 627
			self.Focused = true -- 628
			self.BlinkTimer = 0 -- 629
			self.ShowCursor = true -- 630
			return (self) -- 631
		end, -- 632
		blur = function(self) -- 632
			self.Focused = false -- 633
			self.ShowCursor = false -- 634
			return (self) -- 635
		end, -- 636
		isFocused = function(self) -- 636
			return (self.Focused == true) -- 636
		end, -- 637
		getText = function(self) -- 637
			return (self.Text) -- 637
		end, -- 638
		setText = function(self, value) -- 638
			self.Text = tostring(value or "") -- 639
			self.Cursor = (#self.Text + 1) -- 640
			return (self) -- 641
		end, -- 642
		insert = function(self, value) -- 642
			if not self.Focused then -- 643
				return (self) -- 643
			end -- 643
			ensureType(value, types.STRING) -- 644
			local head = string.sub(self.Text, 1, self.Cursor - 1) -- 645
			local tail = string.sub(self.Text, self.Cursor) -- 646
			self.Text = head .. value .. tail -- 647
			self.Cursor = self.Cursor + (#value) -- 648
			return (self) -- 649
		end, -- 650
		backspace = function(self) -- 650
			if not self.Focused then -- 651
				return (self) -- 651
			end -- 651
			if self.Cursor <= 1 then -- 652
				return (self) -- 652
			end -- 652
			local head = string.sub(self.Text, 1, self.Cursor - 2) -- 653
			local tail = string.sub(self.Text, self.Cursor) -- 654
			self.Text = head .. tail -- 655
			self.Cursor = self.Cursor - 1 -- 656
			return (self) -- 657
		end, -- 658
		delete = function(self) -- 658
			if not self.Focused then -- 659
				return (self) -- 659
			end -- 659
			if self.Cursor > #self.Text then -- 660
				return (self) -- 660
			end -- 660
			local head = string.sub(self.Text, 1, self.Cursor - 1) -- 661
			local tail = string.sub(self.Text, self.Cursor + 1) -- 662
			self.Text = head .. tail -- 663
			return (self) -- 664
		end, -- 665
		moveCursor = function(self, delta) -- 665
			self.Cursor = math.min(math.max((self.Cursor or 1) + tonumber(delta or 0), 1), (#self.Text + 1)) -- 666
			return (self) -- 667
		end, -- 668
		textinput = function(self, value) -- 668
			if not self.Focused then -- 669
				return (self) -- 669
			end -- 669
			self:insert(value) -- 670
			return (self) -- 671
		end, -- 672
		keypressed = function(self, key) -- 672
			if not self.Focused then -- 673
				return (self) -- 673
			end -- 673
			if key == 'backspace' then -- 674
				self:backspace() -- 675
			elseif key == 'delete' then -- 676
				self:delete() -- 677
			elseif key == 'left' then -- 678
				self:moveCursor(-1) -- 679
			elseif key == 'right' then -- 680
				self:moveCursor(1) -- 681
			elseif key == 'home' then -- 682
				self.Cursor = 1 -- 683
			elseif key == 'end' then -- 684
				self.Cursor = (#self.Text + 1) -- 685
			elseif key == 'return' or key == 'kpenter' then -- 686
				self:OnSubmit(self.Text) -- 687
			end -- 674
			return (self) -- 688
		end, -- 689
		update = function(self, dt) -- 689
			if dt == nil then -- 689
				dt = 0 -- 689
			end -- 689
			if not self.Focused then -- 690
				return (self) -- 690
			end -- 690
			self.BlinkTimer = self.BlinkTimer + tonumber(dt or 0) -- 691
			local threshold = (1 / math.max(self.BlinkRate, 0.01)) -- 692
			if self.BlinkTimer >= threshold then -- 693
				self.BlinkTimer = self.BlinkTimer - threshold -- 694
				self.ShowCursor = not (self.ShowCursor == true) -- 695
			end -- 693
			return (self) -- 696
		end, -- 697
		draw = function(self) -- 697
			if (graphics.isActive() == false) then -- 698
				return (nil) -- 698
			end -- 698
			if not self:isVisible() then -- 699
				return (self) -- 699
			end -- 699
			local pX, pY, width, height = self:getBounds() -- 700
			graphics.setColor(unpack(self.Colors.background)) -- 701
			graphics.rectangle('fill', pX, pY, width, height, 3, 3) -- 702
			local borderColor = (self.Focused and self.Colors.focusBorder) or self.Colors.border -- 703
			graphics.setColor(unpack(borderColor)) -- 704
			graphics.rectangle('line', pX, pY, width, height, 3, 3) -- 705
			local activeFont = graphics.getFont() -- 706
			local useFont = self:getFont() -- 707
			if useFont ~= activeFont then -- 708
				graphics.setFont(useFont) -- 708
			end -- 708
			local textColor = ((#self.Text > 0) and self.Colors.text) or self.Colors.placeholder -- 709
			local drawText = (#self.Text > 0) and self.Text or self.Placeholder -- 710
			graphics.setColor(unpack(textColor)) -- 711
			graphics.printf(drawText, pX + self.Padding, pY + self.Padding, width - (self.Padding * 2), 'left') -- 712
			if self.Focused and (self.ShowCursor == true) then -- 713
				local cursorX = pX + self.Padding + useFont:getWidth(string.sub(self.Text, 1, self.Cursor - 1)) -- 714
				graphics.setColor(unpack(self.Colors.cursor)) -- 715
				graphics.rectangle('fill', cursorX, pY + self.Padding, 1, height - (self.Padding * 2)) -- 716
			end -- 713
			graphics.setColor(1, 1, 1, 1) -- 717
			if useFont ~= activeFont then -- 718
				graphics.setFont(activeFont) -- 718
			end -- 718
			return (self) -- 719
		end -- 598
	} -- 598
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 719
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 598
			_base_0[_key_0] = _val_0 -- 598
		end -- 598
	end -- 719
	if _base_0.__index == nil then -- 598
		_base_0.__index = _base_0 -- 598
	end -- 719
	setmetatable(_base_0, _parent_0.__base) -- 598
	_class_0 = setmetatable({ -- 598
		__init = function(self, options) -- 599
			if options == nil then -- 599
				options = nil -- 599
			end -- 599
			local opts = options or { } -- 600
			if (type(options) == types.STRING) then -- 601
				opts = { -- 602
					placeholder = options -- 602
				} -- 602
			end -- 601
			_class_0.__parent.__init(self, opts) -- 603
			self.Placeholder = tostring(opts.placeholder or "") -- 604
			self.Text = tostring(opts.text or opts.value or "") -- 605
			if opts.font then -- 606
				self:setFont(opts.font) -- 606
			end -- 606
			local font = self:getFont() -- 607
			local width = tonumber(opts.width or opts.w or math.max(font:getWidth(self.Text), font:getWidth(self.Placeholder)) + 12) -- 608
			local height = tonumber(opts.height or opts.h or (font:getHeight() + 10)) -- 609
			self:setSize(width, height) -- 610
			self.Padding = tonumber(opts.padding or 6) -- 611
			self.BlinkRate = tonumber(opts.blinkRate or 0.5) -- 612
			self.BlinkTimer = 0 -- 613
			self.ShowCursor = true -- 614
			self.Cursor = (#self.Text + 1) -- 615
			self.Focused = (opts.focused == true) -- 616
			self.Colors = { -- 618
				background = opts.backgroundColor or { -- 618
					0.09, -- 618
					0.09, -- 618
					0.11, -- 618
					1 -- 618
				}, -- 618
				border = opts.borderColor or { -- 619
					0.25, -- 619
					0.25, -- 619
					0.3, -- 619
					1 -- 619
				}, -- 619
				focusBorder = opts.focusBorderColor or { -- 620
					0.9, -- 620
					0.6, -- 620
					0.2, -- 620
					1 -- 620
				}, -- 620
				text = opts.textColor or { -- 621
					1, -- 621
					1, -- 621
					1, -- 621
					1 -- 621
				}, -- 621
				placeholder = opts.placeholderColor or { -- 622
					0.7, -- 622
					0.7, -- 622
					0.75, -- 622
					0.7 -- 622
				}, -- 622
				cursor = opts.cursorColor or { -- 623
					1, -- 623
					1, -- 623
					1, -- 623
					1 -- 623
				} -- 623
			} -- 617
			self.OnSubmit = (opts.onSubmit or NOOP) -- 625
			return (self) -- 626
		end, -- 598
		__base = _base_0, -- 598
		__name = "Textbox", -- 598
		__parent = _parent_0 -- 598
	}, { -- 598
		__index = function(cls, name) -- 598
			local val = rawget(_base_0, name) -- 598
			if val == nil then -- 598
				local parent = rawget(cls, "__parent") -- 598
				if parent then -- 598
					return parent[name] -- 598
				end -- 598
			else -- 598
				return val -- 598
			end -- 598
		end, -- 598
		__call = function(cls, ...) -- 598
			local _self_0 = setmetatable({ }, _base_0) -- 598
			cls.__init(_self_0, ...) -- 598
			return _self_0 -- 598
		end -- 598
	}) -- 598
	_base_0.__class = _class_0 -- 598
	if _parent_0.__inherited then -- 598
		_parent_0.__inherited(_parent_0, _class_0) -- 598
	end -- 598
	Textbox = _class_0 -- 598
end -- 719
local Picture -- 721
do -- 721
	local _class_0 -- 721
	local _parent_0 = Element -- 721
	local _base_0 = { -- 721
		_setImage = function(self, source) -- 747
			if source == nil then -- 748
				error("Picture requires an image source") -- 749
			end -- 748
			local image, path = resolveImageSource(source) -- 750
			self.Image = image -- 751
			if path ~= nil then -- 752
				self.Path = path -- 752
			end -- 752
			if self.Image ~= nil then -- 753
				local width, height = self.Image:getDimensions() -- 754
				self:setSize(width, height) -- 755
			end -- 753
			return (self) -- 756
		end, -- 757
		setImage = function(self, source) -- 757
			self:_setImage(source) -- 758
			return (self) -- 759
		end, -- 760
		reload = function(self) -- 760
			if self.Path ~= nil then -- 761
				self:_setImage(self.Path) -- 761
			end -- 761
			return (self) -- 762
		end, -- 763
		getImage = function(self) -- 763
			return (self.Image) -- 763
		end, -- 764
		getImageData = function(self) -- 764
			if (self.Image == nil) then -- 765
				return (nil) -- 765
			end -- 765
			if self.Image.newImageData then -- 766
				return self.Image:newImageData() -- 767
			elseif self.Image.getData then -- 768
				return self.Image:getData() -- 769
			end -- 766
			return (nil) -- 770
		end, -- 771
		_replaceWithData = function(self, imageData) -- 771
			if imageData == nil then -- 772
				return (self) -- 772
			end -- 772
			self.Image = graphics.newImage(imageData) -- 773
			local width, height = imageData:getDimensions() -- 774
			self:setSize(width, height) -- 775
			return (self) -- 776
		end, -- 777
		draw = function(self, x, y, r, sX, sY, oX, oY) -- 777
			if x == nil then -- 777
				x = nil -- 777
			end -- 777
			if y == nil then -- 777
				y = nil -- 777
			end -- 777
			if r == nil then -- 777
				r = 0 -- 777
			end -- 777
			if sX == nil then -- 777
				sX = 1 -- 777
			end -- 777
			if sY == nil then -- 777
				sY = 1 -- 777
			end -- 777
			if oX == nil then -- 777
				oX = 0 -- 777
			end -- 777
			if oY == nil then -- 777
				oY = 0 -- 777
			end -- 777
			if (graphics.isActive() == false) then -- 778
				return (nil) -- 778
			end -- 778
			if (not self:isVisible()) or (self.Image == nil) then -- 779
				return (self) -- 779
			end -- 779
			local baseX, baseY = self:getPosition() -- 780
			local drawX = tonumber((x ~= nil) and x or baseX) -- 781
			local drawY = tonumber((y ~= nil) and y or baseY) -- 782
			graphics.setColor(1, 1, 1, 1) -- 783
			graphics.draw(self.Image, drawX, drawY, tonumber(r or 0), tonumber(sX or 1), tonumber(sY or 1), tonumber(oX or 0), tonumber(oY or 0)) -- 784
			graphics.setColor(1, 1, 1, 1) -- 785
			return (self) -- 786
		end, -- 787
		getPixel = function(self, x, y) -- 787
			local imageData = self:getImageData() -- 788
			if imageData == nil then -- 789
				return (nil) -- 789
			end -- 789
			return imageData:getPixel(x, y) -- 790
		end, -- 791
		setPixel = function(self, x, y, color) -- 791
			ensureType(color, types.TABLE) -- 792
			assert(#color == 4, [[color table must have 4 values]]) -- 793
			local imageData = self:getImageData() -- 794
			if imageData == nil then -- 795
				return (self) -- 795
			end -- 795
			imageData:setPixel(x, y, color[1], color[2], color[3], color[4]) -- 796
			self:_replaceWithData(imageData) -- 797
			return (self) -- 798
		end, -- 799
		map = function(self, func, x, y, w, h) -- 799
			if x == nil then -- 799
				x = nil -- 799
			end -- 799
			if y == nil then -- 799
				y = nil -- 799
			end -- 799
			if w == nil then -- 799
				w = nil -- 799
			end -- 799
			if h == nil then -- 799
				h = nil -- 799
			end -- 799
			if not isCallable(func) then -- 800
				return (self) -- 800
			end -- 800
			local imageData = self:getImageData() -- 801
			if imageData == nil then -- 802
				return (self) -- 802
			end -- 802
			imageData:mapPixel(func, x, y, w, h) -- 803
			self:_replaceWithData(imageData) -- 804
			return (self) -- 805
		end, -- 806
		encode = function(self, filePath, format) -- 806
			if filePath == nil then -- 806
				filePath = nil -- 806
			end -- 806
			if format == nil then -- 806
				format = 'png' -- 806
			end -- 806
			local imageData = self:getImageData() -- 807
			if imageData == nil then -- 808
				return (nil) -- 808
			end -- 808
			return imageData:encode(format, filePath) -- 809
		end, -- 810
		setFilter = function(self, minFilter, magFilter, anisotropy) -- 810
			if minFilter == nil then -- 810
				minFilter = 'linear' -- 810
			end -- 810
			if magFilter == nil then -- 810
				magFilter = nil -- 810
			end -- 810
			if anisotropy == nil then -- 810
				anisotropy = nil -- 810
			end -- 810
			if self.Image == nil then -- 811
				return (self) -- 811
			end -- 811
			self.Image:setFilter(minFilter, (magFilter or minFilter), anisotropy) -- 812
			return (self) -- 813
		end, -- 814
		setWrap = function(self, wrapH, wrapV) -- 814
			if wrapH == nil then -- 814
				wrapH = 'clamp' -- 814
			end -- 814
			if wrapV == nil then -- 814
				wrapV = nil -- 814
			end -- 814
			if self.Image == nil then -- 815
				return (self) -- 815
			end -- 815
			self.Image:setWrap(wrapH, (wrapV or wrapH)) -- 816
			return (self) -- 817
		end, -- 818
		setMipmapFilter = function(self, filter, sharpness) -- 818
			if sharpness == nil then -- 818
				sharpness = nil -- 818
			end -- 818
			if self.Image == nil then -- 819
				return (self) -- 819
			end -- 819
			self.Image:setMipmapFilter(filter, sharpness) -- 820
			return (self) -- 821
		end, -- 822
		setAnisotropy = function(self, value) -- 822
			if self.Image == nil then -- 823
				return (self) -- 823
			end -- 823
			self.Image:setAnisotropy(tonumber(value or 1)) -- 824
			return (self) -- 825
		end, -- 826
		clone = function(self) -- 826
			local imageData = self:getImageData() -- 827
			if imageData == nil then -- 828
				return (nil) -- 828
			end -- 828
			return Picture(imageData) -- 829
		end -- 721
	} -- 721
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 829
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 721
			_base_0[_key_0] = _val_0 -- 721
		end -- 721
	end -- 829
	if _base_0.__index == nil then -- 721
		_base_0.__index = _base_0 -- 721
	end -- 829
	setmetatable(_base_0, _parent_0.__base) -- 721
	_class_0 = setmetatable({ -- 721
		__init = function(self, source, options) -- 722
			if options == nil then -- 722
				options = nil -- 722
			end -- 722
			local opts = options -- 723
			local imageSource = source -- 724
			if (type(source) == types.TABLE) and (opts == nil) then -- 725
				opts = source -- 726
				imageSource = opts.image or opts.source or opts.path or opts.data -- 727
			elseif (opts ~= nil) and (type(opts) == types.TABLE) and (imageSource == nil) then -- 728
				imageSource = opts.image or opts.source or opts.path or opts.data -- 729
			end -- 725
			_class_0.__parent.__init(self, opts) -- 730
			self.Path = nil -- 731
			self.Image = nil -- 732
			self:_setImage(imageSource) -- 733
			if (opts ~= nil) and (opts.filter ~= nil) then -- 734
				local filter = opts.filter -- 735
				if type(filter) == types.STRING then -- 736
					self:setFilter(filter) -- 737
				elseif type(filter) == types.TABLE then -- 738
					self:setFilter(filter[1], filter[2], filter[3]) -- 739
				end -- 736
			end -- 734
			if (opts ~= nil) and (opts.wrap ~= nil) then -- 740
				local wrap = opts.wrap -- 741
				if type(wrap) == types.STRING then -- 742
					self:setWrap(wrap, wrap) -- 743
				elseif type(wrap) == types.TABLE then -- 744
					self:setWrap(wrap[1], wrap[2] or wrap[1]) -- 745
				end -- 742
			end -- 740
			return (self) -- 746
		end, -- 721
		__base = _base_0, -- 721
		__name = "Picture", -- 721
		__parent = _parent_0 -- 721
	}, { -- 721
		__index = function(cls, name) -- 721
			local val = rawget(_base_0, name) -- 721
			if val == nil then -- 721
				local parent = rawget(cls, "__parent") -- 721
				if parent then -- 721
					return parent[name] -- 721
				end -- 721
			else -- 721
				return val -- 721
			end -- 721
		end, -- 721
		__call = function(cls, ...) -- 721
			local _self_0 = setmetatable({ }, _base_0) -- 721
			cls.__init(_self_0, ...) -- 721
			return _self_0 -- 721
		end -- 721
	}) -- 721
	_base_0.__class = _class_0 -- 721
	if _parent_0.__inherited then -- 721
		_parent_0.__inherited(_parent_0, _class_0) -- 721
	end -- 721
	Picture = _class_0 -- 721
end -- 829
local PictureBatch -- 831
do -- 831
	local _class_0 -- 831
	local _parent_0 = Element -- 831
	local _base_0 = { -- 831
		_setImage = function(self, source) -- 852
			if source == nil then -- 853
				self.Image = nil -- 854
				self.SpriteBatch = nil -- 855
				return (self) -- 856
			end -- 853
			local image, path = resolveImageSource(source) -- 857
			self.Image = image -- 858
			self.Path = path or self.Path -- 859
			if self.Image ~= nil then -- 860
				local width, height = self.Image:getDimensions() -- 861
				self:setSize(width, height) -- 862
				self.SpriteBatch = graphics.newSpriteBatch(self.Image, math.max(1, self.BatchSize), self.Usage) -- 863
				self.SpriteBatch:clear() -- 864
			else -- 866
				self.SpriteBatch = nil -- 866
			end -- 860
			self.Instances = { } -- 867
			return (self) -- 868
		end, -- 869
		setImage = function(self, source) -- 869
			local previousDefs = self.Quads -- 870
			self:_setImage(source) -- 871
			if self.Image ~= nil then -- 872
				self.Quads = { } -- 873
				self.Origins = { } -- 874
				self:defineQuads(self.Sprites) -- 875
			else -- 877
				self.Quads = previousDefs -- 877
			end -- 872
			return (self) -- 878
		end, -- 879
		defineQuads = function(self, definitions) -- 879
			if (definitions == nil) then -- 880
				return (self) -- 880
			end -- 880
			ensureType(definitions, types.TABLE) -- 881
			self.Sprites = definitions -- 882
			for key, def in pairs(definitions) do -- 883
				self:defineQuad(key, def) -- 884
			end -- 884
			return (self) -- 885
		end, -- 886
		defineQuad = function(self, id, def) -- 886
			ensureType(def, types.TABLE) -- 887
			assert(self.Image ~= nil, "Cannot define quad without an image") -- 888
			local x = tonumber(def.x or def[1] or 0) -- 889
			local y = tonumber(def.y or def[2] or 0) -- 890
			local w = tonumber(def.w or def.width or def[3]) -- 891
			local h = tonumber(def.h or def.height or def[4]) -- 892
			assert(w and h, "Quad dimensions must be provided") -- 893
			self.Quads[id] = graphics.newQuad(x, y, w, h, self.Image:getDimensions()) -- 894
			if (def.ox ~= nil) or (def.oy ~= nil) then -- 895
				self.Origins[id] = { -- 896
					tonumber(def.ox or 0), -- 896
					tonumber(def.oy or 0) -- 896
				} -- 896
			else -- 898
				self.Origins[id] = nil -- 898
			end -- 895
			return (self) -- 899
		end, -- 900
		add = function(self, id, x, y, r, sX, sY, oX, oY) -- 900
			if x == nil then -- 900
				x = 0 -- 900
			end -- 900
			if y == nil then -- 900
				y = 0 -- 900
			end -- 900
			if r == nil then -- 900
				r = 0 -- 900
			end -- 900
			if sX == nil then -- 900
				sX = 1 -- 900
			end -- 900
			if sY == nil then -- 900
				sY = 1 -- 900
			end -- 900
			if oX == nil then -- 900
				oX = nil -- 900
			end -- 900
			if oY == nil then -- 900
				oY = nil -- 900
			end -- 900
			if (self.SpriteBatch == nil) then -- 901
				return (nil) -- 901
			end -- 901
			local quad = self.Quads[id] -- 902
			assert(quad, "Unknown quad '" .. tostring(id) .. "'") -- 903
			local origin = self.Origins[id] or { -- 904
				0, -- 904
				0 -- 904
			} -- 904
			local handle = self.SpriteBatch:add(quad, tonumber(x or 0), tonumber(y or 0), tonumber(r or 0), tonumber(sX or 1), tonumber(sY or 1), tonumber(oX or origin[1]), tonumber(oY or origin[2])) -- 905
			self.Instances[#self.Instances + 1] = handle -- 906
			return (handle) -- 907
		end, -- 908
		setInstance = function(self, handle, id, x, y, r, sX, sY, oX, oY) -- 908
			if x == nil then -- 908
				x = 0 -- 908
			end -- 908
			if y == nil then -- 908
				y = 0 -- 908
			end -- 908
			if r == nil then -- 908
				r = 0 -- 908
			end -- 908
			if sX == nil then -- 908
				sX = 1 -- 908
			end -- 908
			if sY == nil then -- 908
				sY = 1 -- 908
			end -- 908
			if oX == nil then -- 908
				oX = nil -- 908
			end -- 908
			if oY == nil then -- 908
				oY = nil -- 908
			end -- 908
			if (self.SpriteBatch == nil) then -- 909
				return (false) -- 909
			end -- 909
			local quad = self.Quads[id] -- 910
			if quad == nil then -- 911
				return (false) -- 911
			end -- 911
			local origin = self.Origins[id] or { -- 912
				0, -- 912
				0 -- 912
			} -- 912
			self.SpriteBatch:set(handle, quad, tonumber(x or 0), tonumber(y or 0), tonumber(r or 0), tonumber(sX or 1), tonumber(sY or 1), tonumber(oX or origin[1]), tonumber(oY or origin[2])) -- 913
			return (true) -- 914
		end, -- 915
		clear = function(self) -- 915
			if self.SpriteBatch ~= nil then -- 916
				self.SpriteBatch:clear() -- 916
			end -- 916
			self.Instances = { } -- 917
			return (self) -- 918
		end, -- 919
		flush = function(self) -- 919
			if self.SpriteBatch ~= nil then -- 920
				self.SpriteBatch:flush() -- 920
			end -- 920
			return (self) -- 921
		end, -- 922
		draw = function(self, id, x, y, r, sX, sY, oX, oY) -- 922
			if id == nil then -- 922
				id = nil -- 922
			end -- 922
			if x == nil then -- 922
				x = 0 -- 922
			end -- 922
			if y == nil then -- 922
				y = 0 -- 922
			end -- 922
			if r == nil then -- 922
				r = 0 -- 922
			end -- 922
			if sX == nil then -- 922
				sX = 1 -- 922
			end -- 922
			if sY == nil then -- 922
				sY = 1 -- 922
			end -- 922
			if oX == nil then -- 922
				oX = 0 -- 922
			end -- 922
			if oY == nil then -- 922
				oY = 0 -- 922
			end -- 922
			if (graphics.isActive() == false) then -- 923
				return (nil) -- 923
			end -- 923
			if not self:isVisible() then -- 924
				return (self) -- 924
			end -- 924
			local baseX, baseY = self:getPosition() -- 925
			if (id == nil) and (self.SpriteBatch ~= nil) then -- 926
				graphics.setColor(1, 1, 1, 1) -- 927
				graphics.draw(self.SpriteBatch, baseX + x, baseY + y, tonumber(r or 0), tonumber(sX or 1), tonumber(sY or 1)) -- 928
				graphics.setColor(1, 1, 1, 1) -- 929
			elseif (self.Image ~= nil) then -- 930
				local quad = self.Quads[id] -- 931
				if quad == nil then -- 932
					return (self) -- 932
				end -- 932
				local origin = self.Origins[id] or { -- 933
					0, -- 933
					0 -- 933
				} -- 933
				graphics.setColor(1, 1, 1, 1) -- 934
				graphics.draw(self.Image, quad, baseX + x, baseY + y, tonumber(r or 0), tonumber(sX or 1), tonumber(sY or 1), tonumber(oX or origin[1]), tonumber(oY or origin[2])) -- 935
				graphics.setColor(1, 1, 1, 1) -- 936
			end -- 926
			return (self) -- 937
		end -- 831
	} -- 831
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 937
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 831
			_base_0[_key_0] = _val_0 -- 831
		end -- 831
	end -- 937
	if _base_0.__index == nil then -- 831
		_base_0.__index = _base_0 -- 831
	end -- 937
	setmetatable(_base_0, _parent_0.__base) -- 831
	_class_0 = setmetatable({ -- 831
		__init = function(self, source, sprites, options) -- 832
			if sprites == nil then -- 832
				sprites = nil -- 832
			end -- 832
			if options == nil then -- 832
				options = nil -- 832
			end -- 832
			local opts = options -- 833
			local definitions = sprites -- 834
			local imageSource = source -- 835
			if (type(source) == types.TABLE) and (opts == nil) then -- 836
				opts = source -- 837
				imageSource = opts.image or opts.source or opts.path or opts.data -- 838
				definitions = opts.sprites or opts.quads or sprites -- 839
			elseif (opts ~= nil) and (type(opts) == types.TABLE) and (imageSource == nil) then -- 840
				imageSource = opts.image or opts.source or opts.path or opts.data -- 841
			end -- 836
			_class_0.__parent.__init(self, opts) -- 842
			self.Quads = { } -- 843
			self.Origins = { } -- 844
			self.Sprites = (definitions or { }) -- 845
			self.Usage = (opts and (opts.usage or 'dynamic')) or 'dynamic' -- 846
			local spriteCount = countEntries(self.Sprites) -- 847
			self.BatchSize = math.max(1, tonumber(opts and (opts.limit or opts.batchSize) or spriteCount or 0) or 64) -- 848
			self:_setImage(imageSource) -- 849
			self:defineQuads(self.Sprites) -- 850
			return (self) -- 851
		end, -- 831
		__base = _base_0, -- 831
		__name = "PictureBatch", -- 831
		__parent = _parent_0 -- 831
	}, { -- 831
		__index = function(cls, name) -- 831
			local val = rawget(_base_0, name) -- 831
			if val == nil then -- 831
				local parent = rawget(cls, "__parent") -- 831
				if parent then -- 831
					return parent[name] -- 831
				end -- 831
			else -- 831
				return val -- 831
			end -- 831
		end, -- 831
		__call = function(cls, ...) -- 831
			local _self_0 = setmetatable({ }, _base_0) -- 831
			cls.__init(_self_0, ...) -- 831
			return _self_0 -- 831
		end -- 831
	}) -- 831
	_base_0.__class = _class_0 -- 831
	if _parent_0.__inherited then -- 831
		_parent_0.__inherited(_parent_0, _class_0) -- 831
	end -- 831
	PictureBatch = _class_0 -- 831
end -- 937
local ConfigGenerator -- 939
do -- 939
	local _class_0 -- 939
	local _parent_0 = FileGenerator -- 939
	local _base_0 = { -- 939
		_writeLines = function(self, lines) -- 946
			ensureType(lines, types.TABLE) -- 947
			self.file_stream:seek('set', 0) -- 948
			self.file_stream:write(table.concat(lines, "\n")) -- 949
			self.file_stream:write("\n") -- 950
			self.file_stream:flush() -- 951
			return (self) -- 952
		end, -- 953
		generate = function(self, options) -- 953
			if options == nil then -- 953
				options = nil -- 953
			end -- 953
			local opts = options or self.Options or { } -- 954
			assert(self:isValid(), "invalid file stream") -- 955
			local windowCfg = opts.window or { } -- 956
			local modulesCfg = opts.modules or { -- 958
				audio = true, -- 958
				data = true, -- 959
				event = true, -- 960
				graphics = true, -- 961
				image = true, -- 962
				joystick = false, -- 963
				keyboard = true, -- 964
				math = true, -- 965
				mouse = true, -- 966
				physics = false, -- 967
				sound = true, -- 968
				system = true, -- 969
				thread = false, -- 970
				timer = true, -- 971
				touch = false, -- 972
				video = false -- 973
			} -- 957
			local identity = opts.identity or "mtlib-prototype" -- 975
			local version = opts.version or "11.5" -- 976
			local title = opts.title or "MTLib Prototype" -- 977
			local lines = { } -- 978
			local indent = '    ' -- 979
			table.insert(lines, "-- Generated by MTLib-Yue ConfigGenerator") -- 980
			table.insert(lines, "function love.conf(t)") -- 981
			table.insert(lines, string.format("%st.identity = %q", indent, identity)) -- 982
			table.insert(lines, string.format("%st.version = %q", indent, version)) -- 983
			table.insert(lines, string.format("%st.console = %s", indent, tostring(opts.console == true))) -- 984
			if opts.gammacorrect ~= nil then -- 985
				table.insert(lines, string.format("%st.gammacorrect = %s", indent, tostring(opts.gammacorrect == true))) -- 986
			end -- 985
			if opts.accelerometer ~= nil then -- 987
				table.insert(lines, string.format("%st.accelerometerjoystick = %s", indent, tostring(opts.accelerometer == true))) -- 988
			end -- 987
			table.insert(lines, string.format("%st.window.title = %q", indent, title)) -- 989
			table.insert(lines, string.format("%st.window.width = %d", indent, tonumber(windowCfg.width or 1280))) -- 990
			table.insert(lines, string.format("%st.window.height = %d", indent, tonumber(windowCfg.height or 720))) -- 991
			if windowCfg.minwidth or windowCfg.minheight then -- 992
				table.insert(lines, string.format("%st.window.minwidth = %d", indent, tonumber(windowCfg.minwidth or 1))) -- 993
				table.insert(lines, string.format("%st.window.minheight = %d", indent, tonumber(windowCfg.minheight or 1))) -- 994
			end -- 992
			if windowCfg.resizable ~= nil then -- 995
				table.insert(lines, string.format("%st.window.resizable = %s", indent, tostring(windowCfg.resizable ~= false))) -- 996
			else -- 998
				table.insert(lines, string.format("%st.window.resizable = %s", indent, tostring(true))) -- 998
			end -- 995
			if windowCfg.vsync ~= nil then -- 999
				table.insert(lines, string.format("%st.window.vsync = %s", indent, tostring(windowCfg.vsync))) -- 1000
			end -- 999
			if windowCfg.msaa ~= nil then -- 1001
				table.insert(lines, string.format("%st.window.msaa = %d", indent, tonumber(windowCfg.msaa))) -- 1002
			end -- 1001
			if windowCfg.highdpi ~= nil then -- 1003
				table.insert(lines, string.format("%st.window.highdpi = %s", indent, tostring(windowCfg.highdpi == true))) -- 1004
			end -- 1003
			if windowCfg.fullscreen ~= nil then -- 1005
				table.insert(lines, string.format("%st.window.fullscreen = %s", indent, tostring(windowCfg.fullscreen == true))) -- 1006
			end -- 1005
			if windowCfg.borderless ~= nil then -- 1007
				table.insert(lines, string.format("%st.window.borderless = %s", indent, tostring(windowCfg.borderless == true))) -- 1008
			end -- 1007
			if windowCfg.centered ~= nil then -- 1009
				table.insert(lines, string.format("%st.window.centered = %s", indent, tostring(windowCfg.centered ~= false))) -- 1010
			end -- 1009
			table.insert(lines, string.format("%st.window.display = %d", indent, tonumber(windowCfg.display or 1))) -- 1011
			if windowCfg.icon then -- 1012
				table.insert(lines, string.format("%st.window.icon = %q", indent, tostring(windowCfg.icon))) -- 1013
			end -- 1012
			local moduleOrder = opts.moduleOrder or { -- 1015
				'audio', -- 1015
				'data', -- 1015
				'event', -- 1015
				'graphics', -- 1015
				'image', -- 1015
				'joystick', -- 1015
				'keyboard', -- 1015
				'math', -- 1015
				'mouse', -- 1015
				'physics', -- 1015
				'sound', -- 1015
				'system', -- 1015
				'thread', -- 1015
				'timer', -- 1015
				'touch', -- 1015
				'video' -- 1015
			} -- 1014
			local seenModules = { } -- 1017
			for _, moduleName in ipairs(moduleOrder) do -- 1018
				local enabled = modulesCfg[moduleName] -- 1019
				if enabled ~= nil then -- 1020
					table.insert(lines, string.format("%st.modules.%s = %s", indent, moduleName, tostring(enabled == true))) -- 1021
					seenModules[moduleName] = true -- 1022
				end -- 1020
			end -- 1022
			for moduleName, enabled in pairs(modulesCfg) do -- 1023
				if not seenModules[moduleName] then -- 1024
					table.insert(lines, string.format("%st.modules.%s = %s", indent, moduleName, tostring(enabled == true))) -- 1025
				end -- 1024
			end -- 1025
			if opts.appenddefault == true then -- 1026
				table.insert(lines, string.format("%st.appendidentity = true", indent)) -- 1027
			end -- 1026
			if opts.extra and type(opts.extra) == types.TABLE then -- 1028
				for _, entry in ipairs(opts.extra) do -- 1029
					if type(entry) == types.STRING then -- 1030
						table.insert(lines, indent .. entry) -- 1031
					end -- 1030
				end -- 1031
			end -- 1028
			table.insert(lines, "end") -- 1032
			self:_writeLines(lines) -- 1033
			return (self) -- 1034
		end -- 939
	} -- 939
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 1034
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 939
			_base_0[_key_0] = _val_0 -- 939
		end -- 939
	end -- 1034
	if _base_0.__index == nil then -- 939
		_base_0.__index = _base_0 -- 939
	end -- 1034
	setmetatable(_base_0, _parent_0.__base) -- 939
	_class_0 = setmetatable({ -- 939
		__init = function(self, fileName, options) -- 940
			if fileName == nil then -- 940
				fileName = 'conf.lua' -- 940
			end -- 940
			if options == nil then -- 940
				options = nil -- 940
			end -- 940
			_class_0.__parent.__init(self, fileName, 'w+') -- 941
			self.Options = options or { } -- 942
			if (self.Options.autoGenerate == true) then -- 943
				self:generate(self.Options) -- 944
			end -- 943
			return (self) -- 945
		end, -- 939
		__base = _base_0, -- 939
		__name = "ConfigGenerator", -- 939
		__parent = _parent_0 -- 939
	}, { -- 939
		__index = function(cls, name) -- 939
			local val = rawget(_base_0, name) -- 939
			if val == nil then -- 939
				local parent = rawget(cls, "__parent") -- 939
				if parent then -- 939
					return parent[name] -- 939
				end -- 939
			else -- 939
				return val -- 939
			end -- 939
		end, -- 939
		__call = function(cls, ...) -- 939
			local _self_0 = setmetatable({ }, _base_0) -- 939
			cls.__init(_self_0, ...) -- 939
			return _self_0 -- 939
		end -- 939
	}) -- 939
	_base_0.__class = _class_0 -- 939
	if _parent_0.__inherited then -- 939
		_parent_0.__inherited(_parent_0, _class_0) -- 939
	end -- 939
	ConfigGenerator = _class_0 -- 939
end -- 1034
return { -- 1037
	View = View, -- 1037
	ListView = ListView, -- 1038
	GridView = GridView, -- 1039
	Element = Element, -- 1040
	Label = Label, -- 1041
	Button = Button, -- 1042
	Textbox = Textbox, -- 1043
	Picture = Picture, -- 1044
	PictureBatch = PictureBatch, -- 1045
	Projector = Projector, -- 1046
	generators = { -- 1048
		ConfigGenerator = ConfigGenerator -- 1048
	}, -- 1047
	patternColorizer = function(str, colors) -- 1050
		ensureType(str, types.STRING) -- 1051
		ensureType(colors, types.TABLE) -- 1052
		local defaultColor = colors.default or { -- 1053
			1, -- 1053
			1, -- 1053
			1, -- 1053
			1 -- 1053
		} -- 1053
		local result = { } -- 1054
		local entries = { } -- 1055
		if colors.order ~= nil then -- 1056
			ensureType(colors.order, types.TABLE) -- 1057
			for _, pattern in ipairs(colors.order) do -- 1058
				if (pattern ~= 'default') and (colors[pattern] ~= nil) then -- 1059
					table.insert(entries, { -- 1060
						pattern = pattern, -- 1060
						data = colors[pattern] -- 1060
					}) -- 1060
				end -- 1059
			end -- 1060
		else -- 1062
			for key, value in pairs(colors) do -- 1062
				if key ~= 'default' then -- 1063
					table.insert(entries, { -- 1064
						pattern = key, -- 1064
						data = value -- 1064
					}) -- 1064
				end -- 1063
			end -- 1064
		end -- 1056
		local append -- 1065
		append = function(color, text) -- 1065
			if (text == nil) or (text == '') then -- 1066
				return -- 1066
			end -- 1066
			if type(color) ~= types.TABLE then -- 1067
				color = defaultColor -- 1067
			end -- 1067
			local count = #result -- 1068
			if (count >= 2) and (result[count - 1] == color) then -- 1069
				result[count] = result[count] .. text -- 1070
			else -- 1072
				table.insert(result, color) -- 1072
				return table.insert(result, text) -- 1073
			end -- 1069
		end -- 1065
		local idx = 1 -- 1074
		local strLength = #str -- 1075
		while idx <= strLength do -- 1076
			local match = nil -- 1077
			local matchColor = nil -- 1078
			local matchTransform = nil -- 1079
			for _, entry in ipairs(entries) do -- 1080
				local pattern = entry.pattern -- 1081
				local data = entry.data -- 1082
				local colorValue = data -- 1083
				local transform = nil -- 1084
				local plainSearch = true -- 1085
				if type(data) == types.TABLE then -- 1086
					transform = data.transform -- 1087
					if data.pattern == true then -- 1088
						plainSearch = false -- 1089
					elseif data.plain ~= nil then -- 1090
						plainSearch = (data.plain ~= false) -- 1091
					end -- 1088
					if data.color then -- 1092
						colorValue = data.color -- 1093
					elseif data[1] ~= nil then -- 1094
						colorValue = data -- 1095
					end -- 1092
				end -- 1086
				local startPos, endPos = string.find(str, pattern, idx, plainSearch) -- 1096
				if (startPos ~= nil) and (startPos == idx) then -- 1097
					if (match == nil) or (endPos > match.e) then -- 1098
						match = { -- 1099
							s = startPos, -- 1099
							e = endPos -- 1099
						} -- 1099
						matchColor = colorValue -- 1100
						matchTransform = transform -- 1101
					end -- 1098
				end -- 1097
			end -- 1101
			if match ~= nil then -- 1102
				local segment = string.sub(str, match.s, match.e) -- 1103
				if (matchTransform ~= nil) and isCallable(matchTransform) then -- 1104
					local transformed = matchTransform(segment) -- 1105
					if transformed ~= nil then -- 1106
						segment = transformed -- 1106
					end -- 1106
				end -- 1104
				append((matchColor or defaultColor), segment) -- 1107
				idx = match.e + 1 -- 1108
			else -- 1110
				append(defaultColor, string.sub(str, idx, idx)) -- 1110
				idx = idx + 1 -- 1111
			end -- 1102
		end -- 1111
		return result -- 1112
	end, -- 1050
	scaleWindow = function(ratio) -- 1113
		if ratio == nil then -- 1113
			ratio = 1 -- 1113
		end -- 1113
		ratio = tonumber(ratio or 1) -- 1114
		if (ratio == nil) or (ratio <= 0) then -- 1115
			error("ratio must be greater than zero") -- 1115
		end -- 1115
		local oldW, oldH, flags = window.getMode() -- 1116
		local origFlags = deepCopy(flags or { }) -- 1117
		local display = (flags and flags.display) or 1 -- 1118
		local success, desktopW, desktopH = pcall(function() -- 1119
			return window.getDesktopDimensions(display) -- 1119
		end) -- 1119
		if not success then -- 1120
			local success2, fallbackW, fallbackH = pcall(function() -- 1121
				return window.getDesktopDimensions(1) -- 1121
			end) -- 1121
			if success2 then -- 1122
				desktopW, desktopH = fallbackW, fallbackH -- 1123
			else -- 1125
				desktopW, desktopH = (oldW * ratio), (oldH * ratio) -- 1125
			end -- 1122
		end -- 1120
		local newW = math.floor(math.min(desktopW, math.max(64, oldW * ratio))) -- 1126
		local newH = math.floor(math.min(desktopH, math.max(64, oldH * ratio))) -- 1127
		local newFlags = deepCopy(flags or { }) -- 1128
		if (desktopW ~= nil) and (desktopH ~= nil) then -- 1129
			newFlags.x = math.floor((desktopW - newW) * 0.5) -- 1130
			newFlags.y = math.floor((desktopH - newH) * 0.5) -- 1131
		end -- 1129
		local oldState = { -- 1132
			width = oldW, -- 1132
			height = oldH, -- 1132
			flags = origFlags, -- 1132
			changed = false -- 1132
		} -- 1132
		if (newW == oldW) and (newH == oldH) then -- 1133
			return (oldState), ({ -- 1134
				width = newW, -- 1134
				height = newH, -- 1134
				flags = deepCopy(newFlags), -- 1134
				changed = false -- 1134
			}) -- 1134
		end -- 1133
		window.setMode(newW, newH, newFlags) -- 1135
		local updatedW, updatedH, updatedFlags = window.getMode() -- 1136
		return (oldState), ({ -- 1137
			width = updatedW, -- 1137
			height = updatedH, -- 1137
			flags = updatedFlags, -- 1137
			changed = true -- 1137
		}) -- 1137
	end, -- 1113
	getCenter = function(offset, offsetY) -- 1138
		if offset == nil then -- 1138
			offset = 0 -- 1138
		end -- 1138
		if offsetY == nil then -- 1138
			offsetY = nil -- 1138
		end -- 1138
		offsetY = offsetY or offset -- 1139
		local width = graphics.getWidth() -- 1140
		local height = graphics.getHeight() -- 1141
		local centerX = (width * 0.5) + tonumber(offset or 0) -- 1142
		local centerY = (height * 0.5) + tonumber(offsetY or 0) -- 1143
		return (math.floor(centerX)), (math.floor(centerY)) -- 1144
	end -- 1138
} -- 1145
