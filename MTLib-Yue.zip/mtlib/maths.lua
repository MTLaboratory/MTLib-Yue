-- [yue]: mtlib/maths.yue
if not RootPath then -- 1
	error("RootPath not set!") -- 1
end -- 1
local MTObj, isInstanceOf -- 2
do -- 2
	local _obj_0 = require(tostring(RootPath) .. "logic") -- 2
	MTObj, isInstanceOf = _obj_0.MTObj, _obj_0.isInstanceOf -- 2
end -- 2
local types -- 3
do -- 3
	local _obj_0 = require(tostring(RootPath) .. "constants") -- 3
	types = _obj_0.types -- 3
end -- 3
local clamp -- 5
clamp = function(v, l, u) -- 5
	if l == nil then -- 5
		l = 0 -- 5
	end -- 5
	if u == nil then -- 5
		u = 1 -- 5
	end -- 5
	return math.max(l, math.min(v, u)) -- 5
end -- 5
local sign -- 7
sign = function(v) -- 7
	return (v < 0 and -1 or 1) -- 8
end -- 7
local sigmoid -- 10
sigmoid = function(v) -- 10
	return (1 / (1 + math.exp(-v))) -- 11
end -- 10
local distance -- 13
distance = function(x, y, x2, y2) -- 13
	return math.abs(math.sqrt(math.pow(x2 - x, 2) + math.pow(y2 - y, 2))) -- 14
end -- 13
local angleBetween -- 16
angleBetween = function(x, y, x2, y2) -- 16
	return math.abs(math.atan2(y2 - y, x2 - x)) -- 17
end -- 16
local invLerp -- 19
invLerp = function(a, b, d) -- 19
	return ((d - a) / (b - a)) -- 20
end -- 19
local cerp -- 22
cerp = function(a, b, d) -- 22
	local pi = (math.pi or 3.1415) -- 23
	local f = (1 - math.cos(d * pi) * 0.5) -- 24
	return (a * (1 - f) + (b * f)) -- 25
end -- 22
local lerp -- 27
lerp = function(a, b, d) -- 27
	return (a + (b - a) * clamp(d)) -- 28
end -- 27
local smooth -- 30
smooth = function(a, b, d) -- 30
	local t = clamp(d) -- 31
	local m = t * t * (3 - 2 * t) -- 32
	return (a + (b - a) * m) -- 33
end -- 30
local pingPong -- 35
pingPong = function(x) -- 35
	return (1 - math.abs(1 - x % 2)) -- 36
end -- 35
local isWithinRegion -- 38
isWithinRegion = function(x, y, oX, oY, lX, lY) -- 38
	return ((x > oX and y < lX) and (y > oY and y < lY)) -- 39
end -- 38
local isWithinCircle -- 41
isWithinCircle = function(x, y, oX, oY, oR) -- 41
	return (distance(x, y, oX, oY) < oR) -- 42
end -- 41
local Dyad -- 51
do -- 51
	local _class_0 -- 51
	local _parent_0 = MTObj -- 51
	local _base_0 = { -- 51
		lerp = function(self, o, d, d1) -- 52
			if isInstanceOf(o, "Dyad") then -- 53
				self.Position.x = lerp(self.Position.x, o.Position.x, tonumber(d)) -- 54
				self.Position.y = lerp(self.Position.y, o.Position.y, tonumber(d)) -- 55
			elseif isType(o, types.NUMBER) then -- 56
				self.Position.x = lerp(self.Position.x, o, d1) -- 57
				self.Position.x = lerp(self.Position.y, d, d1) -- 58
			end -- 53
			return (self) -- 59
		end, -- 60
		get = function(self) -- 60
			return (self.Position.x), (self.Position.y) -- 60
		end, -- 61
		equals = function(self, o, o2) -- 61
			if (o == nil) then -- 62
				return (false) -- 63
			elseif (not isType(o, types.TABLE) and (o2 == nil)) then -- 64
				return (false) -- 65
			elseif isInstanceOf(o, "Dyad") then -- 66
				return ((self.Position.x == o.Position.x) and (self.Position.y == o.Position.y)) -- 70
			elseif (isType(o2, types.NUMBER) and (o ~= nil)) then -- 71
				return ((self.Position.x == o) and (self.Position.y == o2)) -- 72
			end -- 62
			return (false) -- 73
		end, -- 74
		distance = function(self, o, o2) -- 74
			if o == nil then -- 74
				o = 0 -- 74
			end -- 74
			if o2 == nil then -- 74
				o2 = 0 -- 74
			end -- 74
			if (isType(o, types.NUMBER) and isType(o2, types.NUMBER)) then -- 75
				return distance(self.Position.x, self.Position.y, o, o2) -- 76
			end -- 75
			if isInstanceOf(o, "Dyad") then -- 77
				return self:distance(o.Position.x, o.Position.y) -- 78
			end -- 77
			return (nil) -- 79
		end, -- 80
		set = function(self, x, y) -- 80
			self.Position = self.Position or { } -- 81
			self.Position.x, self.Position.y = tonumber(x or 0), tonumber(y or 0) -- 82
			return (self) -- 83
		end, -- 84
		__call = function(self, x, y) -- 84
			return self:set(x, y) -- 84
		end -- 51
	} -- 51
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 87
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 51
			_base_0[_key_0] = _val_0 -- 51
		end -- 51
	end -- 87
	if _base_0.__index == nil then -- 51
		_base_0.__index = _base_0 -- 51
	end -- 87
	setmetatable(_base_0, _parent_0.__base) -- 51
	_class_0 = setmetatable({ -- 51
		__init = function(self, x, y) -- 85
			_class_0.__parent.__init(self) -- 86
			return self(x, y) -- 87
		end, -- 51
		__base = _base_0, -- 51
		__name = "Dyad", -- 51
		__parent = _parent_0 -- 51
	}, { -- 51
		__index = function(cls, name) -- 51
			local val = rawget(_base_0, name) -- 51
			if val == nil then -- 51
				local parent = rawget(cls, "__parent") -- 51
				if parent then -- 51
					return parent[name] -- 51
				end -- 51
			else -- 51
				return val -- 51
			end -- 51
		end, -- 51
		__call = function(cls, ...) -- 51
			local _self_0 = setmetatable({ }, _base_0) -- 51
			cls.__init(_self_0, ...) -- 51
			return _self_0 -- 51
		end -- 51
	}) -- 51
	_base_0.__class = _class_0 -- 51
	if _parent_0.__inherited then -- 51
		_parent_0.__inherited(_parent_0, _class_0) -- 51
	end -- 51
	Dyad = _class_0 -- 51
end -- 87
local Tetrad -- 89
do -- 89
	local _class_0 -- 89
	local _parent_0 = Dyad -- 89
	local _base_0 = { -- 89
		lerp = function(self, o, d) -- 90
			if isInstanceOf(o, "Tetrad") then -- 91
				_class_0.__parent.lerp(self, o, d) -- 92
				self.Velocity.x = lerp(self.Velocity.x, o.Position.x, tonumber(d)) -- 93
				self.Velocity.y = lerp(self.Velocity.y, o.Position.y, tonumber(d)) -- 94
			end -- 91
			return (self) -- 95
		end, -- 96
		distance = function(self, o) -- 96
			return (_class_0.__parent.distance(self, o)) -- 96
		end, -- 97
		set = function(self, x, y, xV, yV) -- 97
			_class_0.__parent.set(self, x, y) -- 98
			self.Velocity = self.Velocity or { } -- 99
			self.Velocity.x, self.Velocity.y = tonumber(xV or 0), tonumber(yV or 0) -- 100
		end, -- 101
		get = function(self) -- 101
			return unpack({ -- 102
				self.Position.x, -- 102
				self.Position.y, -- 102
				self.Velocity.x, -- 103
				self.Velocity.y -- 103
			}) -- 103
		end, -- 104
		update = function(self, dT) -- 104
			if dT == nil then -- 104
				dT = (1 / 60) -- 104
			end -- 104
			local _obj_0 = self.Position -- 105
			_obj_0.x = _obj_0.x + (self.Velocity.x * dT) -- 105
			local _obj_1 = self.Position -- 106
			_obj_1.y = _obj_1.y + (self.Velocity.y * dT) -- 106
		end, -- 107
		impulse = function(self, angle, force) -- 107
			local v = (math.cos(angle) * force) -- 108
			local _obj_0 = self.Velocity -- 109
			_obj_0.x = _obj_0.x + v -- 109
			local _obj_1 = self.Velocity -- 110
			_obj_1.y = _obj_1.y + v -- 110
		end, -- 111
		__call = function(self, x, y, xV, yV) -- 111
			self:set(x, y, xV, yV) -- 112
			return (self) -- 113
		end -- 89
	} -- 89
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 116
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 89
			_base_0[_key_0] = _val_0 -- 89
		end -- 89
	end -- 116
	if _base_0.__index == nil then -- 89
		_base_0.__index = _base_0 -- 89
	end -- 116
	setmetatable(_base_0, _parent_0.__base) -- 89
	_class_0 = setmetatable({ -- 89
		__init = function(self, x, y, xV, yV) -- 114
			_class_0.__parent.__init(self) -- 115
			return self(x, y, xV, yV) -- 116
		end, -- 89
		__base = _base_0, -- 89
		__name = "Tetrad", -- 89
		__parent = _parent_0 -- 89
	}, { -- 89
		__index = function(cls, name) -- 89
			local val = rawget(_base_0, name) -- 89
			if val == nil then -- 89
				local parent = rawget(cls, "__parent") -- 89
				if parent then -- 89
					return parent[name] -- 89
				end -- 89
			else -- 89
				return val -- 89
			end -- 89
		end, -- 89
		__call = function(cls, ...) -- 89
			local _self_0 = setmetatable({ }, _base_0) -- 89
			cls.__init(_self_0, ...) -- 89
			return _self_0 -- 89
		end -- 89
	}) -- 89
	_base_0.__class = _class_0 -- 89
	if _parent_0.__inherited then -- 89
		_parent_0.__inherited(_parent_0, _class_0) -- 89
	end -- 89
	Tetrad = _class_0 -- 89
end -- 116
local Hexad -- 118
do -- 118
	local _class_0 -- 118
	local _parent_0 = Tetrad -- 118
	local _base_0 = { -- 118
		__tostring = function(self) -- 122
			return ("Hexad") -- 122
		end, -- 123
		set = function(self, x, y, xV, yV, r, rV) -- 123
			_class_0.__parent.set(self, x, y, xV, yV) -- 124
			self.Rotator = self.Rotator or { } -- 125
			self.Rotator.value = tonumber(r or 0) -- 126
			self.Rotator.inertia = tonumber(rV or 0) -- 127
			return (self) -- 128
		end, -- 129
		get = function(self) -- 129
			return unpack({ -- 130
				self.Position.x, -- 130
				self.Position.y, -- 130
				self.Velocity.x, -- 131
				self.Velocity.y, -- 131
				self.Rotator.value, -- 132
				self.Rotator.inertia -- 132
			}) -- 132
		end, -- 133
		update = function(self, dT) -- 133
			if dT == nil then -- 133
				dT = (1 / 60) -- 133
			end -- 133
			_class_0.__parent.update(self, dT) -- 134
			local _obj_0 = self.Rotator -- 135
			_obj_0.value = _obj_0.value + (self.Rotator.inertia * dT) -- 135
			return (self) -- 136
		end, -- 137
		torque = function(self, by) -- 137
			local _obj_0 = self.Rotator -- 138
			_obj_0.inertia = _obj_0.inertia + tonumber(by) -- 138
			return (self) -- 139
		end -- 118
	} -- 118
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 139
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 118
			_base_0[_key_0] = _val_0 -- 118
		end -- 118
	end -- 139
	if _base_0.__index == nil then -- 118
		_base_0.__index = _base_0 -- 118
	end -- 139
	setmetatable(_base_0, _parent_0.__base) -- 118
	_class_0 = setmetatable({ -- 118
		__init = function(self, x, y, xV, yV, r, rV) -- 119
			_class_0.__parent.__init(self) -- 120
			return (self:set(x, y, xV, yV, r, rV)) -- 121
		end, -- 118
		__base = _base_0, -- 118
		__name = "Hexad", -- 118
		__parent = _parent_0 -- 118
	}, { -- 118
		__index = function(cls, name) -- 118
			local val = rawget(_base_0, name) -- 118
			if val == nil then -- 118
				local parent = rawget(cls, "__parent") -- 118
				if parent then -- 118
					return parent[name] -- 118
				end -- 118
			else -- 118
				return val -- 118
			end -- 118
		end, -- 118
		__call = function(cls, ...) -- 118
			local _self_0 = setmetatable({ }, _base_0) -- 118
			cls.__init(_self_0, ...) -- 118
			return _self_0 -- 118
		end -- 118
	}) -- 118
	_base_0.__class = _class_0 -- 118
	if _parent_0.__inherited then -- 118
		_parent_0.__inherited(_parent_0, _class_0) -- 118
	end -- 118
	Hexad = _class_0 -- 118
end -- 139
local Octad -- 141
do -- 141
	local _class_0 -- 141
	local _parent_0 = Hexad -- 141
	local _base_0 = { -- 141
		set = function(self, x, y, xV, yV, r, rV, dA, dE) -- 145
			_class_0.__parent.set(self, x, y, xV, yV, r, rV) -- 146
			self.Dimensional = self.Dimensional or { } -- 147
			self.Dimensional.address = tonumber(dA or 0) -- 148
			self.Dimensional.entropy = tonumber(dE or 0) -- 149
			return (self) -- 150
		end, -- 151
		get = function(self) -- 151
			return unpack({ -- 152
				self.Position.x, -- 152
				self.Position.y, -- 152
				self.Velocity.x, -- 153
				self.Velocity.y, -- 153
				self.Rotator.value, -- 154
				self.Rotator.inertia, -- 154
				self.Dimensional.address, -- 155
				self.Dimensional.entropy -- 155
			}) -- 155
		end, -- 156
		shake = function(self, by) -- 156
			local _obj_0 = self.Dimensional -- 157
			_obj_0.entropy = _obj_0.entropy + tonumber(by) -- 157
		end, -- 158
		update = function(self, dT) -- 158
			if dT == nil then -- 158
				dT = (1 / 60) -- 158
			end -- 158
			_class_0.__parent.update(self, dT) -- 159
			local _obj_0 = self.Dimensional -- 160
			_obj_0.address = _obj_0.address + (self.Dimensional.entropy * dT) -- 160
			return (self) -- 161
		end -- 141
	} -- 141
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 161
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 141
			_base_0[_key_0] = _val_0 -- 141
		end -- 141
	end -- 161
	if _base_0.__index == nil then -- 141
		_base_0.__index = _base_0 -- 141
	end -- 161
	setmetatable(_base_0, _parent_0.__base) -- 141
	_class_0 = setmetatable({ -- 141
		__init = function(self, x, y, xV, yV, r, rV, dA, dE) -- 142
			_class_0.__parent.__init(self) -- 143
			return (self:set(x, y, xV, yV, r, rV, dA, dE)) -- 144
		end, -- 141
		__base = _base_0, -- 141
		__name = "Octad", -- 141
		__parent = _parent_0 -- 141
	}, { -- 141
		__index = function(cls, name) -- 141
			local val = rawget(_base_0, name) -- 141
			if val == nil then -- 141
				local parent = rawget(cls, "__parent") -- 141
				if parent then -- 141
					return parent[name] -- 141
				end -- 141
			else -- 141
				return val -- 141
			end -- 141
		end, -- 141
		__call = function(cls, ...) -- 141
			local _self_0 = setmetatable({ }, _base_0) -- 141
			cls.__init(_self_0, ...) -- 141
			return _self_0 -- 141
		end -- 141
	}) -- 141
	_base_0.__class = _class_0 -- 141
	if _parent_0.__inherited then -- 141
		_parent_0.__inherited(_parent_0, _class_0) -- 141
	end -- 141
	Octad = _class_0 -- 141
end -- 161
local Shape -- 163
do -- 163
	local _class_0 -- 163
	local _parent_0 = MTObj -- 163
	local _base_0 = { -- 163
		set = function(self, oX, oY) -- 167
			self.Origin = self.Origin or Dyad(tonumber(oX or 0), tonumber(oY or 0)) -- 168
			return (self) -- 169
		end -- 163
	} -- 163
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 169
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 163
			_base_0[_key_0] = _val_0 -- 163
		end -- 163
	end -- 169
	if _base_0.__index == nil then -- 163
		_base_0.__index = _base_0 -- 163
	end -- 169
	setmetatable(_base_0, _parent_0.__base) -- 163
	_class_0 = setmetatable({ -- 163
		__init = function(self, oX, oY) -- 164
			_class_0.__parent.__init(self) -- 165
			return (self:set(oX, oY)) -- 166
		end, -- 163
		__base = _base_0, -- 163
		__name = "Shape", -- 163
		__parent = _parent_0 -- 163
	}, { -- 163
		__index = function(cls, name) -- 163
			local val = rawget(_base_0, name) -- 163
			if val == nil then -- 163
				local parent = rawget(cls, "__parent") -- 163
				if parent then -- 163
					return parent[name] -- 163
				end -- 163
			else -- 163
				return val -- 163
			end -- 163
		end, -- 163
		__call = function(cls, ...) -- 163
			local _self_0 = setmetatable({ }, _base_0) -- 163
			cls.__init(_self_0, ...) -- 163
			return _self_0 -- 163
		end -- 163
	}) -- 163
	_base_0.__class = _class_0 -- 163
	if _parent_0.__inherited then -- 163
		_parent_0.__inherited(_parent_0, _class_0) -- 163
	end -- 163
	Shape = _class_0 -- 163
end -- 169
local Circle -- 171
do -- 171
	local _class_0 -- 171
	local _parent_0 = Shape -- 171
	local _base_0 = { -- 171
		set = function(self, oX, oY, radi) -- 172
			_class_0.__parent.set(self, oX, oY) -- 173
			self.Radius = tonumber(radi or math.pi) -- 174
			return (self) -- 175
		end, -- 176
		draw = function(self, mode) -- 176
			local love = love or nil -- 177
			if (love == nil) then -- 178
				error('missing LOVE2D!') -- 178
			end -- 178
			love.graphics.circle(mode, self.Origin.x, self.Origin.y, self.Radius) -- 179
			return (self) -- 180
		end -- 171
	} -- 171
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 183
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 171
			_base_0[_key_0] = _val_0 -- 171
		end -- 171
	end -- 183
	if _base_0.__index == nil then -- 171
		_base_0.__index = _base_0 -- 171
	end -- 183
	setmetatable(_base_0, _parent_0.__base) -- 171
	_class_0 = setmetatable({ -- 171
		__init = function(self, x, y, rad) -- 181
			_class_0.__parent.__init(self) -- 182
			return (self:set(x, y, rad)) -- 183
		end, -- 171
		__base = _base_0, -- 171
		__name = "Circle", -- 171
		__parent = _parent_0 -- 171
	}, { -- 171
		__index = function(cls, name) -- 171
			local val = rawget(_base_0, name) -- 171
			if val == nil then -- 171
				local parent = rawget(cls, "__parent") -- 171
				if parent then -- 171
					return parent[name] -- 171
				end -- 171
			else -- 171
				return val -- 171
			end -- 171
		end, -- 171
		__call = function(cls, ...) -- 171
			local _self_0 = setmetatable({ }, _base_0) -- 171
			cls.__init(_self_0, ...) -- 171
			return _self_0 -- 171
		end -- 171
	}) -- 171
	_base_0.__class = _class_0 -- 171
	if _parent_0.__inherited then -- 171
		_parent_0.__inherited(_parent_0, _class_0) -- 171
	end -- 171
	Circle = _class_0 -- 171
end -- 183
local Line -- 185
do -- 185
	local _class_0 -- 185
	local _parent_0 = Shape -- 185
	local _base_0 = { -- 185
		set = function(self, oX, oY, eX, eY) -- 189
			_class_0.__parent.set(self, oX, oY) -- 190
			self.Ending = Dyad(eX, eY) -- 191
			return (self) -- 192
		end, -- 193
		get = function(self) -- 193
			return unpack({ -- 194
				self.Origin.Position.x, -- 194
				self.Origin.Position.y, -- 194
				self.Ending.Position.x, -- 195
				self.Ending.Position.x -- 195
			}) -- 195
		end, -- 197
		getLength = function(self) -- 197
			local sOX, sOY = self.Origin:get() -- 198
			local sEX, sEY = self.Ending:get() -- 199
			return (math.sqrt(math.pow(sEX - sOX, 2) + math.pow(sEY - sOY, 2))) -- 200
		end, -- 201
		getSlope = function(self) -- 201
			return ((self.Ending.Position.x - self.Origin.Position.x) / (self.Ending.Position.y - self.Origin.Position.y)) -- 205
		end, -- 206
		intersects = function(self, o) -- 206
			return error() -- 206
		end -- 185
	} -- 185
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 206
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 185
			_base_0[_key_0] = _val_0 -- 185
		end -- 185
	end -- 206
	if _base_0.__index == nil then -- 185
		_base_0.__index = _base_0 -- 185
	end -- 206
	setmetatable(_base_0, _parent_0.__base) -- 185
	_class_0 = setmetatable({ -- 185
		__init = function(self, oX, oY, eX, eY) -- 186
			_class_0.__parent.__init(self) -- 187
			return (self:set(oX, oY, eX, eY)) -- 188
		end, -- 185
		__base = _base_0, -- 185
		__name = "Line", -- 185
		__parent = _parent_0 -- 185
	}, { -- 185
		__index = function(cls, name) -- 185
			local val = rawget(_base_0, name) -- 185
			if val == nil then -- 185
				local parent = rawget(cls, "__parent") -- 185
				if parent then -- 185
					return parent[name] -- 185
				end -- 185
			else -- 185
				return val -- 185
			end -- 185
		end, -- 185
		__call = function(cls, ...) -- 185
			local _self_0 = setmetatable({ }, _base_0) -- 185
			cls.__init(_self_0, ...) -- 185
			return _self_0 -- 185
		end -- 185
	}) -- 185
	_base_0.__class = _class_0 -- 185
	if _parent_0.__inherited then -- 185
		_parent_0.__inherited(_parent_0, _class_0) -- 185
	end -- 185
	Line = _class_0 -- 185
end -- 206
local Rectangle -- 220
do -- 220
	local _class_0 -- 220
	local _parent_0 = Shape -- 220
	local _base_0 = { -- 220
		set = function(self, oX, oY, lX, lY) -- 224
			_class_0.__parent.set(self, oX, oY) -- 225
			self.Limits = self.Limits or Dyad(lX, lY) -- 226
			return (self) -- 227
		end, -- 228
		get = function(self) -- 228
			return unpack({ -- 229
				self.Origin.Position.x, -- 229
				self.Origin.Position.y, -- 229
				self.Limits.Position.x, -- 230
				self.Limits.Position.y -- 230
			}) -- 230
		end, -- 231
		area = function(self) -- 231
			return (self.Limits.Position.x * self.Limits.Position.y) -- 231
		end, -- 232
		perimeter = function(self) -- 232
			return ((2 * (self.Limits.Position.x)) + (2 * (self.Limits.Position.y))) -- 233
		end, -- 234
		diagonal = function(self) -- 234
			return math.sqrt(((self.Limits.Position.x) ^ 2) + ((self.Limits.Position.y) ^ 2)) -- 235
		end, -- 236
		contains = function(self, o) -- 236
			if isInstanceOf(o, "Dyad") then -- 237
				local sOX, sOY, sLX, sLY = self:get() -- 238
				local oPX, oPY = o:get() -- 239
				return isWithinRegion(oPX, oPY, sOX, sOY, sLX, sLY) -- 240
			elseif isInstanceOf(o, "Line") then -- 241
				return (self:contains(o.Origin) and self:contains(o.Ending)) -- 242
			elseif isInstanceOf(o, "Rectangle") then -- 243
				for i, l in ipairs(o:getLines()) do -- 244
					if (self:contains(l) == false) then -- 245
						return (false) -- 245
					end -- 245
				end -- 245
				return (true) -- 246
			end -- 237
			return (nil) -- 247
		end, -- 248
		render = function(self) -- 248
			local sOX, sOY, sLX, sLY = self:get() -- 249
			return ({ -- 250
				sOX, -- 250
				sOY, -- 250
				sOX, -- 250
				sLY, -- 250
				sOX, -- 251
				sLY, -- 251
				sLX, -- 251
				sLY, -- 251
				sLX, -- 252
				sLY, -- 252
				sLX, -- 252
				sOY, -- 252
				sLX, -- 253
				sOY, -- 253
				sOX, -- 253
				sOY -- 253
			}) -- 253
		end, -- 254
		getLines = function(self) -- 254
			local sOX, sOY, sLX, sLY = self:get() -- 255
			return ({ -- 256
				Line(sOX, sOY, sOX, sLY), -- 256
				Line(sOX, sLY, sLX, sLY), -- 257
				Line(sLX, sLY, sLX, sOY), -- 258
				Line(sLX, sOY, sOX, sOY) -- 259
			}) -- 259
		end -- 220
	} -- 220
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 259
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 220
			_base_0[_key_0] = _val_0 -- 220
		end -- 220
	end -- 259
	if _base_0.__index == nil then -- 220
		_base_0.__index = _base_0 -- 220
	end -- 259
	setmetatable(_base_0, _parent_0.__base) -- 220
	_class_0 = setmetatable({ -- 220
		__init = function(self, oX, oY, lX, lY) -- 221
			_class_0.__parent.__init(self) -- 222
			return (self:set(oX, oY, lX, lY)) -- 223
		end, -- 220
		__base = _base_0, -- 220
		__name = "Rectangle", -- 220
		__parent = _parent_0 -- 220
	}, { -- 220
		__index = function(cls, name) -- 220
			local val = rawget(_base_0, name) -- 220
			if val == nil then -- 220
				local parent = rawget(cls, "__parent") -- 220
				if parent then -- 220
					return parent[name] -- 220
				end -- 220
			else -- 220
				return val -- 220
			end -- 220
		end, -- 220
		__call = function(cls, ...) -- 220
			local _self_0 = setmetatable({ }, _base_0) -- 220
			cls.__init(_self_0, ...) -- 220
			return _self_0 -- 220
		end -- 220
	}) -- 220
	_base_0.__class = _class_0 -- 220
	if _parent_0.__inherited then -- 220
		_parent_0.__inherited(_parent_0, _class_0) -- 220
	end -- 220
	Rectangle = _class_0 -- 220
end -- 259
local Polygon -- 261
do -- 261
	local _class_0 -- 261
	local _parent_0 = Shape -- 261
	local _base_0 = { } -- 261
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 264
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 261
			_base_0[_key_0] = _val_0 -- 261
		end -- 261
	end -- 264
	if _base_0.__index == nil then -- 261
		_base_0.__index = _base_0 -- 261
	end -- 264
	setmetatable(_base_0, _parent_0.__base) -- 261
	_class_0 = setmetatable({ -- 261
		__init = function(self) -- 262
			_class_0.__parent.__init(self) -- 263
			return error() -- 264
		end, -- 261
		__base = _base_0, -- 261
		__name = "Polygon", -- 261
		__parent = _parent_0 -- 261
	}, { -- 261
		__index = function(cls, name) -- 261
			local val = rawget(_base_0, name) -- 261
			if val == nil then -- 261
				local parent = rawget(cls, "__parent") -- 261
				if parent then -- 261
					return parent[name] -- 261
				end -- 261
			else -- 261
				return val -- 261
			end -- 261
		end, -- 261
		__call = function(cls, ...) -- 261
			local _self_0 = setmetatable({ }, _base_0) -- 261
			cls.__init(_self_0, ...) -- 261
			return _self_0 -- 261
		end -- 261
	}) -- 261
	_base_0.__class = _class_0 -- 261
	if _parent_0.__inherited then -- 261
		_parent_0.__inherited(_parent_0, _class_0) -- 261
	end -- 261
	Polygon = _class_0 -- 261
end -- 264
local Color -- 266
do -- 266
	local _class_0 -- 266
	local _base_0 = { -- 266
		__add = function(self, othercolor) -- 273
			if not isInstanceOf(othercolor, "Color") then -- 274
				return (nil) -- 274
			end -- 274
			return Color(clamp(self.R + othercolor.R, 0, 1), clamp(self.G + othercolor.G, 0, 1), clamp(self.B + othercolor.B, 0, 1), clamp(self.A + othercolor.A, 0, 1)) -- 280
		end, -- 281
		__sub = function(self, value) -- 281
			if not isInstanceOf(value, "Color") then -- 282
				return (nil) -- 282
			end -- 282
			return Color(clamp(self.R - value.R, 0, 1), clamp(self.G - value.G, 0, 1), clamp(self.B - value.B, 0, 1), clamp(self.A - value.A, 0, 1)) -- 288
		end, -- 289
		__div = function(self, value) -- 289
			if not isInstanceOf(value, "Color") then -- 290
				return (nil) -- 290
			end -- 290
			return Color(clamp(self.R / value.R, 0, 1), clamp(self.G / value.G, 0, 1), clamp(self.B / value.B, 0, 1), clamp(self.A / value.A, 0, 1)) -- 296
		end, -- 297
		__mul = function(self, value) -- 297
			if not isInstanceOf(value, "Color") then -- 298
				return (nil) -- 298
			end -- 298
			return Color(clamp(self.R * value.R, 0, 1), clamp(self.G * value.G, 0, 1), clamp(self.B * value.B, 0, 1), clamp(self.A * value.A, 0, 1)) -- 304
		end, -- 305
		__eq = function(self, value) -- 305
			if not isInstanceOf(value, "Color") then -- 306
				return (false) -- 306
			end -- 306
			return ((self.R == value.R) and (self.G == value.G) and (self.B == value.B) and (self.A == value.A)) -- 307
		end, -- 308
		__call = function(self) -- 308
			return ({ -- 309
				self.R, -- 309
				self.G, -- 309
				self.B, -- 309
				self.A -- 309
			}) -- 309
		end, -- 310
		__tostring = function(self) -- 310
			return ("Color(" .. tostring(self.R) .. ", " .. tostring(self.G) .. ", " .. tostring(self.B) .. ", " .. tostring(self.A) .. ")") -- 310
		end -- 266
	} -- 266
	if _base_0.__index == nil then -- 266
		_base_0.__index = _base_0 -- 266
	end -- 310
	_class_0 = setmetatable({ -- 266
		__init = function(self, r, g, b, a) -- 267
			if r == nil then -- 267
				r = 1 -- 267
			end -- 267
			if g == nil then -- 267
				g = 1 -- 267
			end -- 267
			if b == nil then -- 267
				b = 1 -- 267
			end -- 267
			if a == nil then -- 267
				a = 1 -- 267
			end -- 267
			self.R = clamp(tonumber(r or 1), 0, 1) -- 268
			self.G = clamp(tonumber(g or 1), 0, 1) -- 269
			self.B = clamp(tonumber(b or 1), 0, 1) -- 270
			self.A = clamp(tonumber(a or 1), 0, 1) -- 271
			return (self) -- 272
		end, -- 266
		__base = _base_0, -- 266
		__name = "Color" -- 266
	}, { -- 266
		__index = _base_0, -- 266
		__call = function(cls, ...) -- 266
			local _self_0 = setmetatable({ }, _base_0) -- 266
			cls.__init(_self_0, ...) -- 266
			return _self_0 -- 266
		end -- 266
	}) -- 266
	_base_0.__class = _class_0 -- 266
	Color = _class_0 -- 266
end -- 310
return { -- 313
	sign = sign, -- 313
	sigmoid = sigmoid, -- 314
	angleBetween = angleBetween, -- 315
	lerp = lerp, -- 316
	inverseLerp = inverseLerp, -- 317
	cosineLerp = cosineLerp, -- 318
	smooth = smooth, -- 319
	pingPong = pingPong, -- 320
	isWithinRegion = isWithinRegion, -- 321
	isWithinCircle = isWithinCircle, -- 322
	Color = Color, -- 324
	Dyad = Dyad, -- 326
	Tetrad = Tetrad, -- 327
	Hexad = Hexad, -- 328
	Octad = Octad, -- 329
	Shape = Shape, -- 331
	Line = Line, -- 332
	Circle = Circle, -- 333
	Rectangle = Rectangle, -- 334
	Polygon = Polygon -- 335
} -- 336
