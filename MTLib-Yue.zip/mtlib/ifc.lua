-- [yue]: mtlib/ifc.yue
local sin -- 3
sin = function(x, y) -- 3
	return math.sin(x), math.sin(y) -- 4
end -- 3
local sphere -- 5
sphere = function(x, y) -- 5
	local fac = (1 / (math.sqrt((x * x) + (y * y)))) -- 6
	return (fac * x), (fac * y) -- 7
end -- 5
local swirl -- 8
swirl = function(x, y) -- 8
	local rsqr = math.sqrt((x * x) + (y * y)) -- 9
	local res_x = ((x * math.sin(rsqr)) - (y * math.cos(rsqr))) -- 10
	local res_y = ((x * math.cos(rsqr)) + (y * math.sin(rsqr))) -- 11
	return res_x, res_y -- 12
end -- 8
local horseshoe -- 13
horseshoe = function(x, y) -- 13
	local factor = (1 / (math.sqrt((x * x) + (y * y)))) -- 14
	return (factor * ((x - y) * (x + y))), (factor * (2 * (x * y))) -- 15
end -- 13
local polar -- 16
polar = function(x, y) -- 16
	return (math.atan(x / y) * math.pi), (((x * x) + (y * y)) - 1) -- 17
end -- 16
local handkerchief -- 18
handkerchief = function(x, y) -- 18
	local r = math.sqrt((x * x) + (y * y)) -- 19
	local arcTan = math.atan(x / y) -- 20
	return (r * math.sin(arcTan + r)), (r * math.cos(arcTan - r)) -- 21
end -- 18
local heart -- 22
heart = function(x, y) -- 22
	local r = math.sqrt((x * x) + (y * y)) -- 23
	local arcTan = math.atan(x / y) -- 24
	return (r * math.sin(arcTan * r)), (r * (-math.cos(arcTan * r))) -- 25
end -- 22
local disc -- 26
disc = function(x, y) -- 26
	local r = math.sqrt((x * x) + (y * y)) -- 27
	local arcTan = math.atan(x / y) -- 28
	local arctanPi = (arcTan * math.pi) -- 29
	return (arctanPi * (math.sin(math.pi * r))), (arctanPi * (math.cos(math.pi * r))) -- 30
end -- 26
local spiral -- 31
spiral = function(x, y) -- 31
	local r = math.sqrt((x * x) + (y * y)) -- 32
	local factor = (1 / (math.sqrt((x * x) + (y * y)))) -- 33
	local arcTan = math.atan(x / y) -- 34
	return (factor * (math.cos(arcTan) + math.sin(r))), (factor * (math.sin(arcTan - math.cos(r)))) -- 35
end -- 31
local hyperbolic -- 36
hyperbolic = function(x, y) -- 36
	local r = math.sqrt((x * x) + (y * y)) -- 37
	local arcTan = math.atan(x / y) -- 38
	return (math.sin(arcTan) / r), (r * math.cos(arcTan)) -- 39
end -- 36
local diamond -- 40
diamond = function(x, y) -- 40
	local r = math.sqrt((x * x) + (y * y)) -- 41
	local arcTan = math.atan(x / y) -- 42
	return (math.sin(arcTan * math.cos(r))), (math.cos(arcTan * math.sin(r))) -- 43
end -- 40
local ex -- 44
ex = function(x, y) -- 44
	local r = math.sqrt((x * x) + (y * y)) -- 45
	local arcTan = math.atan(x / y) -- 46
	local p0 = math.sin(arcTan + r) -- 47
	p0 = math.pow(p0, 3) -- 48
	local p1 = math.cos(arcTan - r) -- 49
	p1 = math.pow(p1, 3) -- 50
	return (r * (p0 + p1)), (r * (p0 - p1)) -- 51
end -- 44
local julia -- 52
julia = function(x, y) -- 52
	local r = math.sqrt((x * x) + (y * y)) -- 53
	local arcTan = math.atan(x / y) -- 54
	local omega -- 55
	if (math.random() >= 0.5) then -- 55
		omega = math.pi -- 55
	else -- 55
		omega = 0 -- 55
	end -- 55
	local res_x = (r * (math.cos((arcTan * 0.5) + omega))) -- 56
	local res_y = (r * (math.sin((arcTan * 0.5) + omega))) -- 57
	return res_x, res_y -- 58
end -- 52
local bent -- 59
bent = function(x, y) -- 59
	if (x < 0 and y >= 0) then -- 60
		return (x * 2), (y) -- 60
	elseif (x >= 0 and y < 0) then -- 61
		return (x), (y * 0.5) -- 61
	elseif (x < 0 and y < 0) then -- 62
		return (x * 2), (y * 0.5) -- 62
	end -- 60
	return (x), (y) -- 63
end -- 59
local waves -- 64
waves = function(x, y, a, b, c, d, e, f) -- 64
	return (x + b * math.sin(y / (c * c))), (y + e * math.sin(x / (f * f))) -- 65
end -- 64
local fisheye -- 66
fisheye = function(x, y) -- 66
	local r = math.sqrt((x * x) + (y * y)) -- 67
	local factor = ((r + 1) * 0.5) -- 68
	return (factor * y), (factor * x) -- 69
end -- 66
local eyefish -- 70
eyefish = function(x, y) -- 70
	local r = math.sqrt((x * x) + (y * y)) -- 71
	local factor = ((r + 1) * 0.5) -- 72
	return (factor * x), (factor * y) -- 73
end -- 70
local popcorn -- 74
popcorn = function(x, y, a, b, c, d, e, f) -- 74
	return (x + c * math.sin(math.tan(3 * y))), (y + f * math.sin(math.tan(3 * x))) -- 75
end -- 74
local power -- 76
power = function(x, y) -- 76
	local r = math.sqrt((x * x) + (y * y)) -- 77
	local arcTan = math.atan(x / y) -- 78
	local factor = r ^ (math.sin(arcTan)) -- 79
	return (factor * (math.cos(arcTan))), (math.sin(arcTan)) -- 80
end -- 76
local cosine -- 81
cosine = function(x, y) -- 81
	local res_x = (math.cos(math.pi * x) * math.cosh(y)) -- 82
	local res_y = (-(math.sin(math.pi * x) * math.sinh(y))) -- 83
	return res_x, res_y -- 84
end -- 81
local rings -- 85
rings = function(x, y, a, b, c, d, e, f) -- 85
	local r = math.sqrt((x * x) + (y * y)) -- 86
	local arcTan = math.atan(x / y) -- 87
	local factor = (r + (c * c)) % (2 * (c * c) - (c * c) + r * (1 - (c * c))) -- 88
	return (factor * math.cos(arcTan)), (factor * math.sin(arcTan)) -- 89
end -- 85
local fan -- 90
fan = function(x, y, a, b, c, d, e, f) -- 90
	local t = (math.pi * (c * c)) -- 91
	local r = math.sqrt((x * x) + (y * y)) -- 92
	local arcTan = math.atan(x / y) -- 93
	if ((arcTan + f) % t) > (t * 0.5) then -- 94
		return (r * math.cos(arcTan - (t * 0.5))), (r * math.sin(arcTan - (t * 0.5))) -- 95
	end -- 94
	return (r * math.cos(arcTan + (t * 0.5))), (r * math.sin(arcTan + (t * 0.5))) -- 96
end -- 90
local blob -- 97
blob = function(x, y, b) -- 97
	local r = math.sqrt((x * x) + (y * y)) -- 98
	local arcTan = math.atan(x / y) -- 99
	local factor = r * (b.Low + ((b.High - b.Low) * 0.5) * math.sin(b.Waves * arcTan) + 1) -- 100
	return (factor * math.cos(arcTan)), (factor * math.sin(arcTan)) -- 101
end -- 97
local pdj -- 102
pdj = function(x, y, a, b, c, d, e, f) -- 102
	return (math.sin(a * y) - math.cos(b * x)), (math.sin(c * x) - math.cos(d * y)) -- 103
end -- 102
local bubble -- 104
bubble = function(x, y) -- 104
	local r = math.sqrt((x * x) + (y * y)) -- 105
	local factor = (4 / ((r * r) + 4)) -- 106
	return (factor * x), (factor * y) -- 107
end -- 104
local cylinder -- 108
cylinder = function(x, y) -- 108
	return (math.sin(x)), (y) -- 109
end -- 108
local perspective -- 110
perspective = function(x, y, angle, dist) -- 110
	local factor = dist / (dist - (y * math.sin(angle))) -- 111
	return (factor * x), (factor * (y * math.cos(angle))) -- 112
end -- 110
local noise -- 113
noise = function(x, y) -- 113
	local rand = math.random(0, 1) -- 114
	local rand2 = math.random(0, 1) -- 115
	local res_x = (rand * (x * math.cos(2 * math.pi * rand2))) -- 116
	local res_y = (rand * (y * math.sin(2 * math.pi * rand2))) -- 117
	return res_x, res_y -- 118
end -- 113
local curl -- 131
curl = function(x, y, c1, c2) -- 131
	local t1 = (1 + (c1 * x) + c2 * ((x * x) - (y * y))) -- 132
	local t2 = (c1 * y) + (2 * c2 * x * y) -- 133
	local factor = (1 / ((t1 * t1) + (t2 * t2))) -- 134
	return (factor * ((x * t1) + (y * t2))), (factor * ((y * t1) - (x * t2))) -- 135
end -- 131
local rectangles -- 136
rectangles = function(x, y, rX, rY) -- 136
	return (((2 * math.floor(x / rX) + 1) * rX) - x), (((2 * math.floor(y / rY) + 1) * rY) - y) -- 137
end -- 136
local tangent -- 138
tangent = function(x, y) -- 138
	return (math.sin(x) / math.cos(y)), (math.tan(y)) -- 139
end -- 138
local cross -- 140
cross = function(x, y) -- 140
	local factor = math.sqrt(1 / (((x * x) - (y * y)) * ((x * x) - (y * y)))) -- 141
	return (factor * x), (factor * y) -- 142
end -- 140
return { -- 145
	transformers = { -- 146
		cross = cross, -- 146
		sin = sin, -- 147
		sphere = sphere, -- 148
		swirl = swirl, -- 149
		horseshoe = horseshoe, -- 150
		polar = polar, -- 151
		handkerchief = handkerchief, -- 152
		heart = heart, -- 153
		disc = disc, -- 154
		spiral = spiral, -- 155
		hyperbolic = hyperbolic, -- 156
		diamond = diamond, -- 157
		ex = ex, -- 158
		julia = julia, -- 159
		bent = bent, -- 160
		waves = waves, -- 161
		fisheye = fisheye, -- 162
		eyefish = eyefish, -- 163
		popcorn = popcorn, -- 164
		power = power, -- 165
		cosine = cosine, -- 166
		rings = rings, -- 167
		fan = fan, -- 168
		blob = blob, -- 169
		pdj = pdj, -- 170
		bubble = bubble, -- 171
		cylinder = cylinder, -- 172
		perspective = perspective, -- 173
		noise = noise, -- 174
		curl = curl, -- 175
		rectangles = rectangles, -- 176
		tangent = tangent -- 177
	} -- 145
} -- 179
