-- [yue]: mtlib/logic.yue
if not RootPath then -- 1
	error("RootPath not set!") -- 1
end -- 1
local types -- 2
do -- 2
	local _obj_0 = require(tostring(RootPath) .. "constants") -- 2
	types = _obj_0.types -- 2
end -- 2
local generateUUID -- 4
generateUUID = function() -- 4
	local fn -- 5
	fn = function(x) -- 5
		local r = (math.random(16) - 1) -- 6
		r = ((x == "x") and (r + 1) or (r % 4) + 9) -- 7
		return (("0123456789abcdef"):sub(r, r)) -- 8
	end -- 5
	return (("xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"):gsub("[xy]", fn)) -- 9
end -- 4
local NOOP -- 11
NOOP = function() -- 11
	return nil -- 11
end -- 11
local isType -- 13
isType = function(value, ofType) -- 13
	return (type(value) == ofType) -- 13
end -- 13
local ensureType -- 15
ensureType = function(value, ofType) -- 15
	if not isType(value, ofType) then -- 16
		return error("Value (type " .. tostring(type(value)) .. ") is not of type " .. tostring(ofType)) -- 17
	end -- 16
end -- 15
local isCallable -- 19
isCallable = function(value) -- 19
	if isType(value, types.FUNC) then -- 20
		return (true) -- 20
	end -- 20
	local mt = getmetatable(value) -- 21
	if (mt ~= nil) and (mt ~= { }) and (mt.__call ~= nil) then -- 22
		return isType(mt.__call, types.FUNC) -- 23
	end -- 22
	return (false) -- 24
end -- 19
local _anon_func_0 = function(pairs, value) -- 29
	local _tbl_0 = { } -- 29
	for k, v in pairs(value) do -- 29
		_tbl_0[k] = v -- 29
	end -- 29
	return _tbl_0 -- 29
end -- 29
local deepCopy -- 26
deepCopy = function(value) -- 26
	if not isType(value, types.TABLE) then -- 27
		return (value) -- 27
	end -- 27
	if (#value == 0) then -- 28
		return ({ }) -- 28
	end -- 28
	return (setmetatable(_anon_func_0(pairs, value), getmetatable(value))) -- 29
end -- 26
local isInstanceOf -- 39
isInstanceOf = function(value, of) -- 39
	if (value == of) then -- 40
		return (true) -- 40
	end -- 40
	if (value.__class ~= nil) then -- 43
		local val_cls = value.__class -- 44
		if (of.__class ~= nil) then -- 45
			local of_cls = of.__class -- 46
			return (val_cls.__name == of_cls.__name) -- 47
		end -- 45
		return (val_cls.__name == of) -- 48
	end -- 43
	return (false) -- 49
end -- 39
local isAncestor -- 51
isAncestor = function(value, of) -- 51
	if (value == nil or of == nil) then -- 52
		return (false) -- 52
	end -- 52
	if (value.__parent) then -- 53
		if isType(of, types.STRING) then -- 54
			return (value.__parent.__name == of) -- 54
		end -- 54
		if (of.__class) then -- 55
			if (value.__parent == of.__class) then -- 56
				return (true) -- 56
			end -- 56
			if (value.__parent.__name == of.__class.__name) then -- 57
				return (true) -- 57
			else -- 58
				return (isAncestor(value.__parent, of)) -- 58
			end -- 57
		end -- 55
	end -- 53
	return (false) -- 59
end -- 51
local are -- 61
are = function(tbl, of) -- 61
	for _, v in pairs(tbl) do -- 62
		if (not isType(v, of)) then -- 63
			return (false) -- 63
		end -- 63
	end -- 63
	return (true) -- 64
end -- 61
local areAncestors -- 66
areAncestors = function(tableOfValues, ofClass) -- 66
	for _, v in pairs(tableOfValues) do -- 67
		if (isAncestor(v, ofClass) == false) then -- 68
			return (false) -- 68
		end -- 68
	end -- 68
	return (true) -- 69
end -- 66
local _anon_func_1 = function(count, fillWith) -- 71
	local _accum_0 = { } -- 71
	local _len_0 = 1 -- 71
	for i = 1, count do -- 71
		_accum_0[_len_0] = (fillWith or 0) -- 71
		_len_0 = _len_0 + 1 -- 71
	end -- 71
	return _accum_0 -- 71
end -- 71
local newArray -- 71
newArray = function(count, fillWith) -- 71
	return (_anon_func_1(count, fillWith)) -- 71
end -- 71
local MTObj -- 73
do -- 73
	local _class_0 -- 73
	local _base_0 = { -- 73
		getID = function(self) -- 82
			return (self.__id) -- 82
		end, -- 83
		free = function(self) -- 83
			self.__class.Heap[self.__id] = nil -- 84
			return (self) -- 85
		end, -- 86
		__tostring = function(self) -- 86
			return ("MTObj") -- 86
		end -- 73
	} -- 73
	if _base_0.__index == nil then -- 73
		_base_0.__index = _base_0 -- 73
	end -- 86
	_class_0 = setmetatable({ -- 73
		__init = function(self) -- 78
			self.__id = generateUUID() -- 79
			self.__class.Heap[self.__id] = self -- 80
			return (self) -- 81
		end, -- 73
		__base = _base_0, -- 73
		__name = "MTObj" -- 73
	}, { -- 73
		__index = _base_0, -- 73
		__call = function(cls, ...) -- 73
			local _self_0 = setmetatable({ }, _base_0) -- 73
			cls.__init(_self_0, ...) -- 73
			return _self_0 -- 73
		end -- 73
	}) -- 73
	_base_0.__class = _class_0 -- 73
	local self = _class_0; -- 73
	self.Heap = { } -- 74
	self.clearHeap = function() -- 75
		self.__class.Heap = { } -- 76
		return (nil) -- 77
	end -- 75
	MTObj = _class_0 -- 73
end -- 86
local List -- 88
do -- 88
	local _class_0 -- 88
	local _parent_0 = MTObj -- 88
	local _base_0 = { -- 88
		clear = function(self) -- 93
			self.Items = { } -- 93
		end, -- 94
		combine = function(self, withTbl) -- 94
			if isType(withTbl, types.TABLE) then -- 95
				for k, v in pairs(withTbl) do -- 96
					self:add(v, k) -- 96
				end -- 96
			end -- 95
			return (self) -- 97
		end, -- 99
		__len = function(self) -- 99
			return #self.Items -- 99
		end, -- 100
		__add = function(v1, v2) -- 100
			if isType(v1, types.TABLE) and isType(v2, types.TABLE) then -- 101
				v1:combine(v2) -- 102
				return (v1) -- 103
			else -- 105
				v1:add(v2) -- 105
				return (v1) -- 106
			end -- 101
			return (nil) -- 107
		end, -- 108
		__index = function(self, k) -- 108
			return (self.Items[k] or nil) -- 108
		end, -- 109
		contains = function(self, value, atKey) -- 109
			if (atKey ~= nil) then -- 110
				local v = self.Items[atKey] -- 111
				if (v ~= nil) then -- 112
					return (value == v) -- 113
				end -- 112
			else -- 114
				for _, v in pairs(self.Items) do -- 114
					if (v == value) then -- 115
						return (true) -- 115
					end -- 115
				end -- 115
			end -- 110
			return (false) -- 116
		end, -- 117
		removeAt = function(self, idx) -- 117
			self.Items[idx] = nil -- 118
			return (self.Items[idx] == nil) -- 119
		end, -- 120
		remove = function(self, item) -- 120
			for k, v in pairs(self.Items) do -- 121
				if (v == item) then -- 122
					self.Items[k] = nil -- 123
					return (true) -- 124
				end -- 122
			end -- 124
			return (false) -- 125
		end, -- 126
		forEach = function(self, doFunc, iterations) -- 126
			if iterations == nil then -- 126
				iterations = 1 -- 126
			end -- 126
			for k, v in pairs(self.Items) do -- 127
				for i = 1, iterations do -- 128
					self.Items[k] = (doFunc(v, i, k) or v) -- 129
				end -- 129
			end -- 129
			return (self) -- 130
		end, -- 131
		add = function(self, v, k) -- 131
			k = (k or (#self.Items + 1)) -- 132
			self.Items[k] = deepCopy(v) -- 133
			self.Top = self.Items[k] -- 134
			return (self) -- 135
		end, -- 136
		topKey = function(self) -- 136
			local lK = nil -- 137
			for k, _ in pairs(self.Items) do -- 138
				lK = k -- 138
			end -- 138
			return (lK) -- 139
		end, -- 140
		top = function(self) -- 140
			if (self.Top ~= nil) then -- 141
				return (self.Top) -- 141
			end -- 141
			return (self.Items[self:topKey()] or nil) -- 142
		end, -- 143
		pop = function(self, atKey) -- 143
			table.remove(self.Items, (atKey or #self.Items)) -- 144
			return (self) -- 145
		end -- 88
	} -- 88
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 145
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 88
			_base_0[_key_0] = _val_0 -- 88
		end -- 88
	end -- 145
	if _base_0.__index == nil then -- 88
		_base_0.__index = _base_0 -- 88
	end -- 145
	setmetatable(_base_0, _parent_0.__base) -- 88
	_class_0 = setmetatable({ -- 88
		__init = function(self, ofItems) -- 89
			_class_0.__parent.__init(self) -- 90
			do -- 91
				local _tbl_0 = { } -- 91
				for k, v in pairs(ofItems) do -- 91
					_tbl_0[k] = v -- 91
				end -- 91
				self.Items = _tbl_0 -- 91
			end -- 91
			return (self) -- 92
		end, -- 88
		__base = _base_0, -- 88
		__name = "List", -- 88
		__parent = _parent_0 -- 88
	}, { -- 88
		__index = function(cls, name) -- 88
			local val = rawget(_base_0, name) -- 88
			if val == nil then -- 88
				local parent = rawget(cls, "__parent") -- 88
				if parent then -- 88
					return parent[name] -- 88
				end -- 88
			else -- 88
				return val -- 88
			end -- 88
		end, -- 88
		__call = function(cls, ...) -- 88
			local _self_0 = setmetatable({ }, _base_0) -- 88
			cls.__init(_self_0, ...) -- 88
			return _self_0 -- 88
		end -- 88
	}) -- 88
	_base_0.__class = _class_0 -- 88
	if _parent_0.__inherited then -- 88
		_parent_0.__inherited(_parent_0, _class_0) -- 88
	end -- 88
	List = _class_0 -- 88
end -- 145
local Timer -- 149
do -- 149
	local _class_0 -- 149
	local _parent_0 = MTObj -- 149
	local _base_0 = { -- 149
		__tostring = function(self) -- 150
			return ("Timer") -- 150
		end, -- 151
		update = function(self, dT) -- 151
			local now = os.clock() -- 152
			local love = love or nil -- 153
			if (love ~= nil) then -- 154
				dT = (dT or love.timer.getDelta()) -- 155
			else -- 157
				dT = (dT or (now - (self.lastUpdate or now))) -- 157
			end -- 154
			self.timeRemaining = self.timeRemaining - dT -- 158
			self.lastUpdate = now -- 159
			if (self.timeRemaining <= 0) then -- 160
				if (self.oneShot == true and not self.hasShot) then -- 161
					self:onComplete() -- 162
					self.hasShot = true -- 163
					return (true) -- 164
				end -- 161
				if (self.looping == true) then -- 165
					self:restart() -- 165
				end -- 165
				self:onComplete() -- 166
				return (true) -- 167
			end -- 160
			return (false) -- 168
		end, -- 169
		isComplete = function(self) -- 169
			return ((self.timeRemaining <= 0) and (self.looping == false)) -- 170
		end, -- 171
		restart = function(self) -- 171
			self.timeRemaining = self.duration -- 172
			return (self) -- 173
		end -- 149
	} -- 149
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 184
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 149
			_base_0[_key_0] = _val_0 -- 149
		end -- 149
	end -- 184
	if _base_0.__index == nil then -- 149
		_base_0.__index = _base_0 -- 149
	end -- 184
	setmetatable(_base_0, _parent_0.__base) -- 149
	_class_0 = setmetatable({ -- 149
		__init = function(self, duration, onComplete, oneShot, looping) -- 174
			if oneShot == nil then -- 174
				oneShot = true -- 174
			end -- 174
			if looping == nil then -- 174
				looping = false -- 174
			end -- 174
			_class_0.__parent.__init(self) -- 175
			duration = duration or 1.0 -- 176
			self.duration = duration -- 177
			self.oneShot = oneShot -- 178
			self.hasShot = false -- 179
			self.onComplete = (onComplete or NOOP) -- 180
			self.looping = looping -- 181
			self.lastUpdate = os.clock() -- 182
			self:restart() -- 183
			return (self) -- 184
		end, -- 149
		__base = _base_0, -- 149
		__name = "Timer", -- 149
		__parent = _parent_0 -- 149
	}, { -- 149
		__index = function(cls, name) -- 149
			local val = rawget(_base_0, name) -- 149
			if val == nil then -- 149
				local parent = rawget(cls, "__parent") -- 149
				if parent then -- 149
					return parent[name] -- 149
				end -- 149
			else -- 149
				return val -- 149
			end -- 149
		end, -- 149
		__call = function(cls, ...) -- 149
			local _self_0 = setmetatable({ }, _base_0) -- 149
			cls.__init(_self_0, ...) -- 149
			return _self_0 -- 149
		end -- 149
	}) -- 149
	_base_0.__class = _class_0 -- 149
	if _parent_0.__inherited then -- 149
		_parent_0.__inherited(_parent_0, _class_0) -- 149
	end -- 149
	Timer = _class_0 -- 149
end -- 184
return { -- 187
	NOOP = NOOP, -- 187
	generateUUID = generateUUID, -- 188
	isCallable = isCallable, -- 189
	isType = isType, -- 190
	deepCopy = deepCopy, -- 191
	isInstanceOf = isInstanceOf, -- 192
	ensureType = ensureType, -- 193
	isAncestor = isAncestor, -- 194
	are = are, -- 195
	areAncestors = areAncestors, -- 196
	newArray = newArray, -- 197
	Timer = Timer, -- 199
	List = List, -- 200
	MTObj = MTObj -- 201
} -- 202
