-- [yue]: mtlib/license.yue
return [[Don't Be A Dick Public License]] -- 1
