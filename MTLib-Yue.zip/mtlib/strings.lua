-- [yue]: mtlib/strings.yue
if not RootPath then -- 1
	error("RootPath not set!") -- 1
end -- 1
local types -- 2
do -- 2
	local _obj_0 = require(tostring(RootPath) .. "constants") -- 2
	types = _obj_0.types -- 2
end -- 2
local isType, MTObj -- 3
do -- 3
	local _obj_0 = require(tostring(RootPath) .. "logic") -- 3
	isType, MTObj = _obj_0.isType, _obj_0.MTObj -- 3
end -- 3
local getValueAddress -- 5
getValueAddress = function(f, l) -- 5
	if ((l == nil) and isType(f, types.FUNC)) then -- 6
		l = true -- 6
	end -- 6
	return (tostring(((l and "0x") or "")) .. tostring((tostring(f):gsub("%a*:%s*0?", ""):upper()))) -- 7
end -- 5
local serialize -- 9
serialize = function(what, depth, seen) -- 9
	if depth == nil then -- 9
		depth = 0 -- 9
	end -- 9
	if seen == nil then -- 9
		seen = { } -- 9
	end -- 9
	local tokens = { -- 11
		[types.NIL] = tostring, -- 11
		[types.FUNC] = tostring, -- 12
		[types.USERDATA] = tostring, -- 13
		[types.THREAD] = tostring, -- 14
		[types.BOOL] = tostring, -- 15
		[types.STRING] = function(s) -- 16
			return string.format("%q", s) -- 16
		end, -- 16
		[types.NUMBER] = function(num) -- 17
			return string.format("%f", num) -- 17
		end, -- 17
		[types.TABLE] = function(t) -- 18
			local rtn = { } -- 19
			seen[t] = tostring(t) -- 20
			depth = depth + 1 -- 21
			local tab = ("\t"):rep(depth) -- 22
			local class_id -- 23
			if what.__class then -- 23
				class_id = "class: " .. tostring(tostring(t):gsub("table: ", "")) .. " " -- 24
			else -- 24
				class_id = "" -- 24
			end -- 23
			for k, m in pairs(t) do -- 25
				if (k == "__parent") then -- 26
					goto _continue_0 -- 26
				end -- 26
				if (seen[m] ~= nil) then -- 27
					rtn[(#rtn) + 1] = (tab .. "[" .. tostring(tostring(k)) .. "] = recursion(" .. tostring(tostring(m)) .. ")\n") -- 28
				else -- 30
					rtn[(#rtn) + 1] = (tab .. "[" .. tostring(tostring(k)) .. "] = " .. tostring(serialize(m, depth, seen)) .. "\n") -- 30
				end -- 27
				::_continue_0:: -- 26
			end -- 30
			seen[t] = nil -- 31
			return (class_id .. "{\n" .. table.concat(rtn, "") .. ("\t"):rep(depth - 1) .. "}") -- 32
		end -- 18
	} -- 10
	return (tokens[type(what)](what, seen)) -- 34
end -- 9
return { -- 37
	UUID = UUID, -- 37
	getValueAddress = getValueAddress, -- 38
	serialize = serialize -- 39
} -- 40
