-- [yue]: mtlib/constants.yue
return { -- 2
	types = { -- 3
		TABLE = [[table]], -- 3
		FUNC = [[function]], -- 4
		STRING = [[string]], -- 5
		NIL = [[nil]], -- 6
		BOOL = [[boolean]], -- 7
		USERDATA = [[userdata]], -- 8
		THREAD = [[thread]], -- 9
		NUMBER = [[number]] -- 10
	} -- 2
} -- 12
