-- [yue]: mtlib/security.yue
if not RootPath then -- 1
	error("RootPath not set!") -- 1
end -- 1
local MTObj, List, ensureType -- 2
do -- 2
	local _obj_0 = require(tostring(RootPath) .. "logic") -- 2
	MTObj, List, ensureType = _obj_0.MTObj, _obj_0.List, _obj_0.ensureType -- 2
end -- 2
local types -- 3
do -- 3
	local _obj_0 = require(tostring(RootPath) .. "constants") -- 3
	types = _obj_0.types -- 3
end -- 3
local Salt -- 5
do -- 5
	local _class_0 -- 5
	local _parent_0 = MTObj -- 5
	local _base_0 = { -- 5
		hash = function(self, data) -- 14
			return ensureType(data, types.STRING) -- 15
		end, -- 16
		__tostring = function(self) -- 16
			return tostring(self) -- 17
		end -- 5
	} -- 5
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 17
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 5
			_base_0[_key_0] = _val_0 -- 5
		end -- 5
	end -- 17
	if _base_0.__index == nil then -- 5
		_base_0.__index = _base_0 -- 5
	end -- 17
	setmetatable(_base_0, _parent_0.__base) -- 5
	_class_0 = setmetatable({ -- 5
		__init = function(self, size) -- 7
			ensureType(data, types.NUMBER) -- 8
			self.Data = { } -- 9
			for i = 1, size do -- 10
				local rand_index = math.random(1, #(self.__class.Chars)) -- 11
				table.insert(self.Data, self.__class.Chars:sub(rand_index, rand_index)) -- 12
			end -- 12
			return (self) -- 13
		end, -- 5
		__base = _base_0, -- 5
		__name = "Salt", -- 5
		__parent = _parent_0 -- 5
	}, { -- 5
		__index = function(cls, name) -- 5
			local val = rawget(_base_0, name) -- 5
			if val == nil then -- 5
				local parent = rawget(cls, "__parent") -- 5
				if parent then -- 5
					return parent[name] -- 5
				end -- 5
			else -- 5
				return val -- 5
			end -- 5
		end, -- 5
		__call = function(cls, ...) -- 5
			local _self_0 = setmetatable({ }, _base_0) -- 5
			cls.__init(_self_0, ...) -- 5
			return _self_0 -- 5
		end -- 5
	}) -- 5
	_base_0.__class = _class_0 -- 5
	local self = _class_0; -- 5
	self.Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" -- 6
	if _parent_0.__inherited then -- 5
		_parent_0.__inherited(_parent_0, _class_0) -- 5
	end -- 5
	Salt = _class_0 -- 5
end -- 17
local Authenticator -- 19
do -- 19
	local _class_0 -- 19
	local _parent_0 = MTObj -- 19
	local _base_0 = { -- 19
		clear = function(self) -- 24
			return self.Keys:clear() -- 25
		end, -- 26
		register = function(self, key) -- 26
			if not isType(key, types.STRING) then -- 27
				return (false) -- 27
			end -- 27
			self.Keys[#self.Keys] = key -- 28
			return (true) -- 29
		end, -- 30
		registerEach = function(self, keys) -- 30
			for _, key in pairs(keys) do -- 31
				self:register(key) -- 31
			end -- 31
		end, -- 32
		validate = function(self, key, doHash) -- 32
			if doHash == nil then -- 32
				doHash = false -- 32
			end -- 32
			if doHash then -- 33
				local _base_1 = self.MasterKey -- 34
				local _fn_0 = _base_1.hash -- 34
				key = _fn_0 and function(...) -- 34
					return _fn_0(_base_1, ...) -- 34
				end -- 34
			end -- 33
			for _, k in pairs(self.Keys) do -- 35
				if (key == k) then -- 36
					return (true) -- 36
				end -- 36
			end -- 36
			return (false) -- 37
		end -- 19
	} -- 19
	for _key_0, _val_0 in pairs(_parent_0.__base) do -- 37
		if _base_0[_key_0] == nil and _key_0:match("^__") and not (_key_0 == "__index" and _val_0 == _parent_0.__base) then -- 19
			_base_0[_key_0] = _val_0 -- 19
		end -- 19
	end -- 37
	if _base_0.__index == nil then -- 19
		_base_0.__index = _base_0 -- 19
	end -- 37
	setmetatable(_base_0, _parent_0.__base) -- 19
	_class_0 = setmetatable({ -- 19
		__init = function(self, masterKeySize) -- 20
			if masterKeySize == nil then -- 20
				masterKeySize = 128 -- 20
			end -- 20
			ensureType(data, types.NUMBER) -- 21
			self.MasterKey = Salt(masterKeySize) -- 22
			self.Keys = List() -- 23
		end, -- 19
		__base = _base_0, -- 19
		__name = "Authenticator", -- 19
		__parent = _parent_0 -- 19
	}, { -- 19
		__index = function(cls, name) -- 19
			local val = rawget(_base_0, name) -- 19
			if val == nil then -- 19
				local parent = rawget(cls, "__parent") -- 19
				if parent then -- 19
					return parent[name] -- 19
				end -- 19
			else -- 19
				return val -- 19
			end -- 19
		end, -- 19
		__call = function(cls, ...) -- 19
			local _self_0 = setmetatable({ }, _base_0) -- 19
			cls.__init(_self_0, ...) -- 19
			return _self_0 -- 19
		end -- 19
	}) -- 19
	_base_0.__class = _class_0 -- 19
	if _parent_0.__inherited then -- 19
		_parent_0.__inherited(_parent_0, _class_0) -- 19
	end -- 19
	Authenticator = _class_0 -- 19
end -- 37
return { -- 40
	Salt = Salt, -- 40
	Authenticator = Authenticator -- 41
} -- 42
