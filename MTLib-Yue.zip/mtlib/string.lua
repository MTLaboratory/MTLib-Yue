local types
do
	local _obj_0 = require([[mtlib.constants]])
	types = _obj_0.types
end
local isType, MTObj
do
	local _obj_0 = require([[mtlib.logic]])
	isType, MTObj = _obj_0.isType, _obj_0.MTObj
end
local getValueAddress
getValueAddress = function(f, l)
	if ((l == nil) and isType(f, types.FUNC)) then
		l = true
	end
	return (tostring(((l and "0x") or "")) .. tostring((tostring(f):gsub("%a*:%s*0?", ""):upper())))
end
local serialize
serialize = function(what, depth, seen)
	if depth == nil then
		depth = 0
	end
	if seen == nil then
		seen = { }
	end
	local tokens = {
		[types.NIL] = tostring,
		[types.FUNC] = tostring,
		[types.USERDATA] = tostring,
		[types.THREAD] = tostring,
		[types.BOOL] = tostring,
		[types.STRING] = function(s)
			return string.format("%q", s)
		end,
		[types.NUMBER] = function(num)
			return string.format("%f", num)
		end,
		[types.TABLE] = function(t)
			local rtn = { }
			seen[t] = tostring(t)
			depth = depth + 1
			local tab = ("\t"):rep(depth)
			local class_id
			if what.__class then
				class_id = "class: " .. tostring(tostring(t):gsub("table: ", "")) .. " "
			else
				class_id = ""
			end
			for k, m in pairs(t) do
				if (k == "__parent") then
					goto _continue_0
				end
				if (seen[m] ~= nil) then
					rtn[(#rtn) + 1] = (tab .. "[" .. tostring(tostring(k)) .. "] = recursion(" .. tostring(tostring(m)) .. ")\n")
				else
					rtn[(#rtn) + 1] = (tab .. "[" .. tostring(tostring(k)) .. "] = " .. tostring(serialize(m, depth, seen)) .. "\n")
				end
				::_continue_0::
			end
			seen[t] = nil
			return (class_id .. "{\n" .. table.concat(rtn, "") .. ("\t"):rep(depth - 1) .. "}")
		end
	}
	return (tokens[type(what)](what, seen))
end
return {
	UUID = UUID,
	getValueAddress = getValueAddress,
	serialize = serialize
}
