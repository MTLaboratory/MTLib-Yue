-- [yue]: mtlib.yue
RootPath = ... .. '.' -- 1
if RootPath == null then -- 3
	return error("Module path not provided") -- 4
end -- 3
return { -- 8
	_NAME = [[MTLibrary]], -- 8
	_AUTHOR = [[MTadder]], -- 9
	_AUTHOR_EMAIL = [[MTadder@pm.me]], -- 10
	_YUEVERSION = [[0.29.4]], -- 11
	_LUAVERSION = [[5.4]], -- 12
	_VERSION_NO = [[0.9.1]], -- 13
	_VERSION_NAME = [[Innoculate Laminae]], -- 14
	_LICENSE = require(tostring(RootPath) .. "license"), -- 15
	security = require(tostring(RootPath) .. "security"), -- 18
	ifc = require(tostring(RootPath) .. "ifc"), -- 19
	maths = require(tostring(RootPath) .. "maths"), -- 20
	love = require(tostring(RootPath) .. "love"), -- 21
	logic = require(tostring(RootPath) .. "logic"), -- 22
	strings = require(tostring(RootPath) .. "strings"), -- 23
	constants = require(tostring(RootPath) .. "constants") -- 24
} -- 25
